# -*- coding: utf-8 -*-
"""
/***************************************************************************
 checkcoordinatesys - ui_theme
                                 A QGIS plugin
 Sinh mau sac va stylesheet bam theo bang mau (palette) dang dung cua QGIS
 de giao dien hoat dong tot voi ca giao dien sang lan toi.
                              -------------------
        begin                : 2016-10-06
        copyright            : (C) 2016 by GFD
        email                : hoa.lq@gfd.com.vn
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtGui import QColor, QPalette

#: Mau chu phu (nhan mo) cho giao dien sang va giao dien toi.
MUTED_LIGHT = '#57606a'
MUTED_DARK = '#9aa4b2'


def is_dark(palette):
    """True neu bang mau dang dung la giao dien toi."""
    return palette.color(QPalette.ColorRole.Window).lightness() < 128


def muted_color(palette):
    """Mau chu phu doc duoc tren nen cua giao dien dang dung."""
    return MUTED_DARK if is_dark(palette) else MUTED_LIGHT


def mix(first, second, ratio):
    """Tron hai mau theo ti le, ratio = 0 tra ve mau thu nhat."""
    return QColor(
        int(round(first.red() + (second.red() - first.red()) * ratio)),
        int(round(first.green() + (second.green() - first.green()) * ratio)),
        int(round(first.blue() + (second.blue() - first.blue()) * ratio)),
    )


def _readable_text_on(color):
    """Chon mau chu den hay trang de doc ro tren nen da cho."""
    return QColor('#ffffff') if color.lightness() < 150 else QColor('#101010')


def dialog_stylesheet(palette):
    """Sinh stylesheet cho hop thoai tu bang mau hien tai."""
    dark = is_dark(palette)
    window = palette.color(QPalette.ColorRole.Window)
    base = palette.color(QPalette.ColorRole.Base)
    text = palette.color(QPalette.ColorRole.WindowText)
    accent = palette.color(QPalette.ColorRole.Highlight)

    surface = mix(window, text, 0.06) if dark else base
    control = mix(window, text, 0.10) if dark else mix(window, text, 0.04)
    hover = mix(control, text, 0.10)
    pressed = mix(control, text, 0.18)
    border = mix(window, text, 0.22)
    subtle_border = mix(window, text, 0.14)
    alternate = mix(base, text, 0.045)
    selection = mix(base, accent, 0.28)
    accent_hover = mix(accent, _readable_text_on(accent), 0.15)
    accent_text = _readable_text_on(accent)

    return u"""
QDialog#CrsCheckDialog {{
    background: {window};
}}
QLabel#titleLabel {{
    font-size: 14pt;
    font-weight: 600;
    color: {text};
}}
QLabel#subtitleLabel, QLabel#summaryLabel {{
    color: {muted};
}}
QFrame#toolbarCard {{
    background: {surface};
    border: 1px solid {subtle_border};
    border-radius: 10px;
}}
QLineEdit#searchEdit {{
    background: {base};
    border: 1px solid {border};
    border-radius: 8px;
    padding: 6px 10px;
    color: {text};
    selection-background-color: {accent};
    selection-color: {accent_text};
}}
QLineEdit#searchEdit:focus {{
    border: 1px solid {accent};
}}
QComboBox#groupCombo {{
    background: {base};
    border: 1px solid {border};
    border-radius: 8px;
    padding: 5px 10px;
    color: {text};
    min-width: 150px;
}}
QComboBox#groupCombo:focus {{
    border: 1px solid {accent};
}}
QComboBox#groupCombo::drop-down {{
    border: 0;
    width: 20px;
}}
QCheckBox {{
    color: {text};
    spacing: 6px;
}}
QPushButton {{
    background: {control};
    border: 1px solid {border};
    border-radius: 8px;
    padding: 6px 14px;
    color: {text};
}}
QPushButton:hover {{
    background: {hover};
}}
QPushButton:pressed {{
    background: {pressed};
}}
QPushButton:disabled {{
    color: {muted};
    background: transparent;
    border: 1px solid {subtle_border};
}}
QPushButton#primaryButton {{
    background: {accent};
    border: 1px solid {accent};
    color: {accent_text};
    font-weight: 600;
}}
QPushButton#primaryButton:hover {{
    background: {accent_hover};
}}
QTreeWidget#resultTree {{
    background: {base};
    alternate-background-color: {alternate};
    border: 1px solid {subtle_border};
    border-radius: 10px;
    color: {text};
    outline: 0;
}}
QTreeWidget#resultTree::item {{
    padding: 5px 4px;
    border: 0;
}}
QTreeWidget#resultTree::item:selected {{
    background: {selection};
    color: {text};
}}
QHeaderView::section {{
    background: {surface};
    color: {muted};
    border: 0;
    border-bottom: 1px solid {border};
    padding: 7px 8px;
    font-weight: 600;
}}
QAbstractScrollArea::corner {{
    background: transparent;
    border: 0;
}}
QScrollBar:vertical {{
    background: transparent;
    width: 12px;
    margin: 0;
    border: 0;
}}
QScrollBar:horizontal {{
    background: transparent;
    height: 12px;
    margin: 0;
    border: 0;
}}
QScrollBar::handle:vertical {{
    background: {border};
    border-radius: 3px;
    min-height: 28px;
    margin: 3px;
}}
QScrollBar::handle:horizontal {{
    background: {border};
    border-radius: 3px;
    min-width: 28px;
    margin: 3px;
}}
QScrollBar::handle:hover {{
    background: {scroll_hover};
}}
/* Phai khai bao day du cac thanh phan con, neu khong Qt se ve lai
   scrollbar bang kieu mac dinh va sinh ra vet ke soc. */
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0;
    height: 0;
    background: transparent;
    border: 0;
}}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical,
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
    background: transparent;
}}
""".format(
        window=window.name(),
        base=base.name(),
        text=text.name(),
        surface=surface.name(),
        control=control.name(),
        hover=hover.name(),
        pressed=pressed.name(),
        border=border.name(),
        subtle_border=subtle_border.name(),
        alternate=alternate.name(),
        selection=selection.name(),
        accent=accent.name(),
        accent_hover=accent_hover.name(),
        accent_text=accent_text.name(),
        scroll_hover=mix(border, text, 0.35).name(),
        muted=muted_color(palette),
    )
