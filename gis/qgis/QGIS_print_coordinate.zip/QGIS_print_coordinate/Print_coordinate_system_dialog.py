# -*- coding: utf-8 -*-
"""
/***************************************************************************
 checkcoordinatesysDialog
                                 A QGIS plugin
 Hien thi he toa do cua tat ca cac lop trong du an
                             -------------------
        begin                : 2016-10-06
        copyright            : (C) 2016 by GFD
        email                : hoa.lq@gfd.com.vn
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import codecs
import os
import re

from qgis.PyQt.QtCore import QEvent, QSize, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
)
from qgis.core import QgsProject

from .crs_inspector import collect_layer_info, layer_icon, tr
from .ui_theme import dialog_stylesheet

#: Cac su kien bao hieu bang mau da doi. Khong duoc them StyleChange vao day:
#: setStyleSheet() tu sinh ra su kien do nen se gay de quy vo han.
#: ThemeChange khong co tren moi ban Qt nen phai tra cuu mem deo.
_PALETTE_EVENTS = tuple(
    event for event in (
        getattr(QEvent.Type, 'PaletteChange', None),
        getattr(QEvent.Type, 'ApplicationPaletteChange', None),
        getattr(QEvent.Type, 'ThemeChange', None),
    ) if event is not None
)

LAYER_ID_ROLE = Qt.ItemDataRole.UserRole + 1
SEARCH_ROLE = Qt.ItemDataRole.UserRole + 2

COLUMN_LAYER = 0
COLUMN_TYPE = 1
COLUMN_CRS = 2
COLUMN_DETAIL = 3
COLUMN_AUTHID = 4
COLUMN_UNITS = 5
COLUMN_COUNT = 6

GROUP_NONE = 'none'
GROUP_CRS = 'crs'

#: Ky tu mo dau khien Excel va LibreOffice coi o do la cong thuc.
_FORMULA_LEAD = u'=+@\t\r'
#: So am thuc su thi van de nguyen, khong can danh dau.
_NUMBER_PATTERN = re.compile(r'^-\d')


def neutralise_formula(value):
    """Chan mot o bang bi doc thanh cong thuc khi mo bang bang tinh.

    Ten lop va mo ta he toa do deu doc tu tep du an, ma tep du an co the do
    nguoi khac gui den. Mot lop dat ten la ``=HYPERLINK(...)`` se chay nhu
    cong thuc khi nguoi dung mo tep CSV, nen phai them dau nhay don o dau:
    Excel hieu day la danh dau van ban va khong hien thi no trong o.
    """
    if not value:
        return value
    if value[0] in _FORMULA_LEAD:
        return u"'" + value
    if value[0] == u'-' and not _NUMBER_PATTERN.match(value):
        return u"'" + value
    return value


class CrsCheckDialog(QDialog):
    """Hop thoai liet ke he toa do cua moi lop trong du an."""

    def __init__(self, iface=None, parent=None):
        super(CrsCheckDialog, self).__init__(parent)
        self.iface = iface
        self._records = []
        self._connected_project = None
        self._applying_theme = False

        self.setObjectName('CrsCheckDialog')
        self.setWindowTitle(
            tr(u'Coordinate System Check / Kiểm tra hệ tọa độ'))
        self.setWindowFlags(Qt.WindowType.Window)
        # Rong hon mac dinh vi moi nhan deu viet ca tieng Viet lan tieng Anh.
        self.resize(1180, 560)

        self._build_ui()
        self._apply_theme()
        self._connect_project_signals()

    # ------------------------------------------------------------------
    # Xay dung giao dien
    # ------------------------------------------------------------------
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(12)

        layout.addLayout(self._build_header())
        layout.addWidget(self._build_toolbar())
        layout.addWidget(self._build_tree(), 1)
        layout.addLayout(self._build_footer())

    def _build_header(self):
        header = QHBoxLayout()
        header.setSpacing(12)

        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            icon_label = QLabel()
            icon_label.setPixmap(QIcon(icon_path).pixmap(QSize(36, 36)))
            header.addWidget(icon_label, 0, Qt.AlignmentFlag.AlignTop)

        titles = QVBoxLayout()
        titles.setSpacing(2)
        self.title_label = QLabel(
            tr(u'Coordinate System Check / Kiểm tra hệ tọa độ'))
        self.title_label.setObjectName('titleLabel')
        self.subtitle_label = QLabel(
            tr(u'Check the coordinate system of map layers / '
               u'Kiểm tra hệ tọa độ của lớp bản đồ'))
        self.subtitle_label.setObjectName('subtitleLabel')
        titles.addWidget(self.title_label)
        titles.addWidget(self.subtitle_label)
        header.addLayout(titles, 1)
        return header

    def _build_toolbar(self):
        card = QFrame()
        card.setObjectName('toolbarCard')
        row = QHBoxLayout(card)
        row.setContentsMargins(12, 10, 12, 10)
        row.setSpacing(10)

        self.search_edit = QLineEdit()
        self.search_edit.setObjectName('searchEdit')
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.setPlaceholderText(
            tr(u'Search layer, CRS, EPSG code… / '
               u'Tìm tên lớp, hệ tọa độ, mã EPSG…'))
        self.search_edit.textChanged.connect(self._apply_filter)
        row.addWidget(self.search_edit, 1)

        self.group_combo = QComboBox()
        self.group_combo.setObjectName('groupCombo')
        self.group_combo.addItem(
            tr(u'Flat list / Danh sách phẳng'), GROUP_NONE)
        self.group_combo.addItem(
            tr(u'Group by CRS / Gom theo hệ tọa độ'), GROUP_CRS)
        self.group_combo.currentIndexChanged.connect(self._populate_tree)
        row.addWidget(self.group_combo)

        self.refresh_button = QPushButton(tr(u'Refresh / Làm mới'))
        self.refresh_button.clicked.connect(self.refresh)
        row.addWidget(self.refresh_button)
        return card

    def _build_tree(self):
        self.tree = QTreeWidget()
        self.tree.setObjectName('resultTree')
        self.tree.setColumnCount(COLUMN_COUNT)
        self.tree.setHeaderLabels(self._column_titles())
        self.tree.setRootIsDecorated(False)
        self.tree.setUniformRowHeights(True)
        self.tree.setAlternatingRowColors(True)
        self.tree.setSortingEnabled(True)
        self.tree.sortByColumn(-1, Qt.SortOrder.AscendingOrder)
        self.tree.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows)
        self.tree.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._show_context_menu)
        self.tree.itemDoubleClicked.connect(self._on_item_double_clicked)

        header = self.tree.header()
        for column in range(self.tree.columnCount()):
            header.setSectionResizeMode(
                column, QHeaderView.ResizeMode.Interactive)
        # Cot "Chi tiet" chua chuoi dai nhat nen duoc gian ra lap khoang trong.
        header.setSectionResizeMode(
            COLUMN_DETAIL, QHeaderView.ResizeMode.Stretch)
        header.setStretchLastSection(False)
        self.tree.setColumnWidth(COLUMN_LAYER, 200)
        self.tree.setColumnWidth(COLUMN_TYPE, 120)
        self.tree.setColumnWidth(COLUMN_CRS, 200)
        self.tree.setColumnWidth(COLUMN_AUTHID, 95)
        self.tree.setColumnWidth(COLUMN_UNITS, 85)
        return self.tree

    def _column_titles(self):
        return [
            tr(u'Layer / Lớp'),
            tr(u'Type / Loại'),
            tr(u'Coordinate system / Hệ tọa độ'),
            tr(u'Details / Chi tiết'),
            tr(u'Code / Mã'),
            tr(u'Unit / Đơn vị'),
        ]

    def _build_footer(self):
        footer = QHBoxLayout()
        footer.setSpacing(8)

        self.summary_label = QLabel()
        self.summary_label.setObjectName('summaryLabel')
        self.summary_label.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        footer.addWidget(self.summary_label, 1)

        self.copy_button = QPushButton(tr(u'Copy / Sao chép'))
        self.copy_button.setToolTip(
            tr(u'Copy the result table to the clipboard / '
               u'Sao chép bảng kết quả vào bộ nhớ tạm'))
        self.copy_button.clicked.connect(self._copy_to_clipboard)
        footer.addWidget(self.copy_button)

        self.export_button = QPushButton(tr(u'Export CSV / Xuất CSV'))
        self.export_button.setToolTip(
            tr(u'Export the visible rows to a CSV file / '
               u'Xuất các dòng đang hiển thị ra tệp CSV'))
        self.export_button.clicked.connect(self._export_csv)
        footer.addWidget(self.export_button)

        # Chua co du lieu thi hai lenh nay khong bam duoc.
        self._set_data_actions_enabled(False)

        self.close_button = QPushButton(tr(u'Close / Đóng'))
        self.close_button.setObjectName('primaryButton')
        self.close_button.setDefault(True)
        self.close_button.clicked.connect(self.close)
        footer.addWidget(self.close_button)
        return footer

    # ------------------------------------------------------------------
    # Giao dien sang / toi
    # ------------------------------------------------------------------
    def _apply_theme(self):
        # setStyleSheet() phat lai su kien doi bang mau, phai chan de quy.
        if self._applying_theme:
            return
        self._applying_theme = True
        try:
            self.setStyleSheet(dialog_stylesheet(self.palette()))
            self.tree.viewport().update()
        finally:
            self._applying_theme = False

    def changeEvent(self, event):
        """Ap dung lai mau khi nguoi dung doi giao dien QGIS luc dang mo."""
        if event.type() in _PALETTE_EVENTS:
            self._apply_theme()
        super(CrsCheckDialog, self).changeEvent(event)

    # ------------------------------------------------------------------
    # Du lieu
    # ------------------------------------------------------------------
    def _project_signals(self, project):
        return [
            signal for signal in (
                getattr(project, 'layersAdded', None),
                getattr(project, 'layersRemoved', None),
                getattr(project, 'crsChanged', None),
                getattr(project, 'cleared', None),
            ) if signal is not None
        ]

    def _connect_project_signals(self):
        if self._connected_project is not None:
            return
        project = QgsProject.instance()
        for signal in self._project_signals(project):
            signal.connect(self.refresh)
        self._connected_project = project

    def _disconnect_project_signals(self):
        project = self._connected_project
        if project is None:
            return
        for signal in self._project_signals(project):
            try:
                signal.disconnect(self.refresh)
            except (TypeError, RuntimeError):
                pass
        self._connected_project = None

    def refresh(self, *args):
        """Doc lai danh sach lop va ve lai bang ket qua."""
        del args
        self._records = collect_layer_info()
        self._populate_tree()

    def _populate_tree(self, *args):
        del args
        self.tree.setUpdatesEnabled(False)
        self.tree.clear()

        grouped = self.group_combo.currentData() == GROUP_CRS
        self.tree.setRootIsDecorated(grouped)

        if grouped:
            groups = {}
            for record in self._records:
                groups.setdefault(record.group_key, []).append(record)
            for key in sorted(groups):
                members = groups[key]
                parent = QTreeWidgetItem(self.tree)
                parent.setText(
                    COLUMN_LAYER,
                    tr(u'{0}  ({1} layers / lớp)').format(key, len(members)))
                parent.setFirstColumnSpanned(True)
                font = parent.font(COLUMN_LAYER)
                font.setBold(True)
                parent.setFont(COLUMN_LAYER, font)
                parent.setData(COLUMN_LAYER, SEARCH_ROLE, key.lower())
                for record in members:
                    self._create_item(parent, record)
                parent.setExpanded(True)
        else:
            for record in self._records:
                self._create_item(self.tree, record)

        self.tree.setUpdatesEnabled(True)
        self._apply_filter()

    def _create_item(self, parent, record):
        item = QTreeWidgetItem(parent)
        item.setText(COLUMN_LAYER, record.layer_name)
        item.setText(COLUMN_TYPE, record.type_label)
        item.setText(COLUMN_CRS, record.crs.title)
        item.setText(COLUMN_DETAIL, record.crs.detail)
        item.setText(COLUMN_AUTHID, record.crs.authid or u'—')
        item.setText(COLUMN_UNITS, record.crs.units)
        item.setData(COLUMN_LAYER, LAYER_ID_ROLE, record.layer_id)

        icon = layer_icon(record.layer)
        if icon is not None:
            item.setIcon(COLUMN_LAYER, icon)

        searchable = u' '.join([
            record.layer_name,
            record.type_label,
            record.crs.title,
            record.crs.detail,
            record.crs.authid,
            record.crs.units,
        ]).lower()
        item.setData(COLUMN_LAYER, SEARCH_ROLE, searchable)

        tooltip_lines = [
            u'<b>{0}</b>'.format(record.layer_name),
            u'{0}: {1}'.format(
                tr(u'Coordinate system / Hệ tọa độ'), record.crs.title),
        ]
        if record.crs.detail:
            tooltip_lines.append(record.crs.detail)
        if record.crs.authid:
            tooltip_lines.append(u'{0}: {1}'.format(
                tr(u'Code / Mã'), record.crs.authid))
        if record.crs.proj:
            tooltip_lines.append(
                u'<br><code>{0}</code>'.format(record.crs.proj))
        tooltip = u'<br>'.join(tooltip_lines)
        for column in range(self.tree.columnCount()):
            item.setToolTip(column, tooltip)
        return item

    # ------------------------------------------------------------------
    # Loc du lieu
    # ------------------------------------------------------------------
    def _apply_filter(self, *args):
        del args
        needle = self.search_edit.text().strip().lower()
        visible = 0

        for index in range(self.tree.topLevelItemCount()):
            top_item = self.tree.topLevelItem(index)
            if top_item.childCount() == 0:
                matched = self._item_matches(top_item, needle)
                top_item.setHidden(not matched)
                visible += 1 if matched else 0
                continue

            shown_children = 0
            for child_index in range(top_item.childCount()):
                child = top_item.child(child_index)
                matched = self._item_matches(child, needle)
                child.setHidden(not matched)
                shown_children += 1 if matched else 0
            top_item.setHidden(shown_children == 0)
            visible += shown_children

        self._set_data_actions_enabled(visible > 0)
        self._update_summary(visible)

    def _set_data_actions_enabled(self, enabled):
        """Bat / tat cac lenh chi co nghia khi bang dang co du lieu."""
        self.copy_button.setEnabled(enabled)
        self.export_button.setEnabled(enabled)

    def _item_matches(self, item, needle):
        if not needle:
            return True
        haystack = item.data(COLUMN_LAYER, SEARCH_ROLE) or ''
        return needle in haystack

    def _update_summary(self, visible):
        total = len(self._records)
        if total == 0:
            self.summary_label.setText(
                tr(u'No layers in this project. / Dự án chưa có lớp nào.'))
            return

        distinct = len({record.group_key for record in self._records})
        parts = [
            tr(u'{0} layers / lớp').format(total),
            tr(u'{0} coordinate systems / hệ tọa độ').format(distinct),
        ]
        if visible != total:
            parts.append(tr(u'showing {0} / đang hiển thị {0}').format(visible))
        self.summary_label.setText(u'  ·  '.join(parts))

    # ------------------------------------------------------------------
    # Hanh dong
    # ------------------------------------------------------------------
    def _selected_records(self):
        selected_ids = set()
        for item in self.tree.selectedItems():
            layer_id = item.data(COLUMN_LAYER, LAYER_ID_ROLE)
            if layer_id:
                selected_ids.add(layer_id)
        return [record for record in self._records
                if record.layer_id in selected_ids]

    def _visible_records(self):
        """Ban ghi dang hien thi, giu nguyen thu tu tren bang."""
        visible_ids = []

        def walk(item):
            if item.isHidden():
                return
            layer_id = item.data(COLUMN_LAYER, LAYER_ID_ROLE)
            if layer_id:
                visible_ids.append(layer_id)
            for index in range(item.childCount()):
                walk(item.child(index))

        for index in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(index))

        by_id = {record.layer_id: record for record in self._records}
        return [by_id[layer_id] for layer_id in visible_ids if layer_id in by_id]

    def _table_rows(self, records):
        """Du lieu dung chung cho ca xuat CSV lan sao chep vao bo nho tam."""
        rows = [self._column_titles()]
        for record in records:
            rows.append([neutralise_formula(cell) for cell in (
                record.layer_name,
                record.type_label,
                record.crs.title,
                record.crs.detail,
                record.crs.authid,
                record.crs.units,
            )])
        return rows

    def _copy_to_clipboard(self):
        records = self._selected_records() or self._visible_records()
        if not records:
            return
        text = u'\n'.join(
            u'\t'.join(cell or u'' for cell in row)
            for row in self._table_rows(records))
        QApplication.clipboard().setText(text)
        self.summary_label.setText(
            tr(u'Copied {0} rows. / Đã sao chép {0} dòng.').format(
                len(records)))

    def _export_csv(self):
        records = self._visible_records()
        if not records:
            return
        path, _ = QFileDialog.getSaveFileName(
            self,
            tr(u'Export coordinate system list / Xuất danh sách hệ tọa độ'),
            'he_toa_do.csv', tr(u'CSV file / Tệp CSV (*.csv)'))
        if not path:
            return

        def escape(value):
            value = value or u''
            if any(character in value for character in u',"\r\n'):
                return u'"{0}"'.format(value.replace(u'"', u'""'))
            return value

        try:
            # BOM giup Excel nhan dien dung UTF-8 co dau tieng Viet.
            with codecs.open(path, 'w', encoding='utf-8-sig') as handle:
                for row in self._table_rows(records):
                    handle.write(u','.join(escape(cell) for cell in row))
                    handle.write(u'\n')
        except (IOError, OSError) as error:
            QMessageBox.warning(
                self, tr(u'Export failed / Không xuất được tệp'),
                u'{0}'.format(error))
            return
        self.summary_label.setText(
            tr(u'Exported / Đã xuất: {0}').format(path))

    def _show_context_menu(self, position):
        records = self._selected_records()
        if not records:
            return
        record = records[0]

        menu = QMenu(self)
        copy_action = menu.addAction(
            tr(u'Copy selected rows / Sao chép dòng đã chọn'))
        copy_proj_action = menu.addAction(
            tr(u'Copy PROJ string / Sao chép chuỗi PROJ'))
        copy_wkt_action = menu.addAction(tr(u'Copy WKT / Sao chép WKT'))
        menu.addSeparator()
        set_project_action = menu.addAction(
            tr(u'Set as project CRS / Đặt làm hệ tọa độ dự án'))
        set_project_action.setEnabled(record.crs.valid)

        zoom_action = None
        properties_action = None
        if self.iface is not None:
            menu.addSeparator()
            zoom_action = menu.addAction(tr(u'Zoom to layer / Phóng tới lớp'))
            properties_action = menu.addAction(
                tr(u'Layer properties… / Mở thuộc tính lớp'))

        chosen = menu.exec(self.tree.viewport().mapToGlobal(position))
        if chosen is None:
            return

        if chosen is copy_action:
            self._copy_to_clipboard()
        elif chosen is copy_proj_action:
            QApplication.clipboard().setText(record.crs.proj)
        elif chosen is copy_wkt_action:
            QApplication.clipboard().setText(record.crs.wkt)
        elif chosen is set_project_action:
            QgsProject.instance().setCrs(record.layer.crs())
        elif zoom_action is not None and chosen is zoom_action:
            self.iface.setActiveLayer(record.layer)
            self.iface.zoomToActiveLayer()
        elif properties_action is not None and chosen is properties_action:
            self.iface.showLayerProperties(record.layer)

    def _on_item_double_clicked(self, item, column):
        del column
        layer_id = item.data(COLUMN_LAYER, LAYER_ID_ROLE)
        if not layer_id or self.iface is None:
            return
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is not None:
            self.iface.showLayerProperties(layer)

    def showEvent(self, event):
        # Hop thoai duoc dung lai giua cac lan mo nen phai noi lai tin hieu.
        self._connect_project_signals()
        super(CrsCheckDialog, self).showEvent(event)

    def closeEvent(self, event):
        self._disconnect_project_signals()
        super(CrsCheckDialog, self).closeEvent(event)


#: Giu ten cu de cac doan ma tham chieu truoc day van hoat dong.
checkcoordinatesysDialog = CrsCheckDialog
