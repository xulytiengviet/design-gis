# -*- coding: utf-8 -*-
"""
/***************************************************************************
 checkcoordinatesys
                                 A QGIS plugin
 Hien thi he toa do cua tat ca cac lop trong du an
                              -------------------
        begin                : 2016-10-06
        git sha              : $Format:%H$
        copyright            : (C) 2016 by GFD
        email                : hoa.lq@gfd.com.vn
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os.path

from qgis.PyQt.QtCore import QCoreApplication, QLocale, QSettings, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .Print_coordinate_system_dialog import CrsCheckDialog

PLUGIN_MENU = u'&Coordinate System / Kiểm tra hệ tọa độ'


class checkcoordinatesys(object):
    """Diem vao cua plugin trong QGIS."""

    def __init__(self, iface):
        """Ham khoi tao.

        :param iface: Doi tuong giao tiep voi QGIS luc chay.
        :type iface: QgisInterface
        """
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr(PLUGIN_MENU)
        self.dlg = None
        self.translator = None

        self._install_translator()

    def _install_translator(self):
        """Nap ban dich theo ngon ngu dang dung cua QGIS, neu co."""
        locale = QSettings().value('locale/userLocale')
        if not locale:
            locale = QLocale.system().name()
        locale = str(locale)[0:2]
        locale_path = os.path.join(
            self.plugin_dir, 'i18n', 'checkcoordinatesys_{0}.qm'.format(locale))
        if not os.path.exists(locale_path):
            return
        self.translator = QTranslator()
        if self.translator.load(locale_path):
            QCoreApplication.installTranslator(self.translator)

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Dich chuoi qua Qt translation API.

        :param message: Chuoi can dich.
        :type message: str

        :returns: Chuoi da dich.
        :rtype: str
        """
        return QCoreApplication.translate('checkcoordinatesys', message)

    def add_action(self, icon_path, text, callback, enabled_flag=True,
                   add_to_menu=True, add_to_toolbar=True, status_tip=None,
                   whats_this=None, parent=None):
        """Tao mot QAction va dang ky vao menu / thanh cong cu.

        :param icon_path: Duong dan toi bieu tuong cua lenh.
        :type icon_path: str

        :param text: Nhan hien thi trong menu.
        :type text: str

        :param callback: Ham duoc goi khi kich hoat lenh.
        :type callback: function

        :param enabled_flag: Cho phep su dung lenh hay khong.
        :type enabled_flag: bool

        :param add_to_menu: Them lenh vao menu Plugins hay khong.
        :type add_to_menu: bool

        :param add_to_toolbar: Them lenh vao thanh cong cu hay khong.
        :type add_to_toolbar: bool

        :param status_tip: Chu giai hien o thanh trang thai.
        :type status_tip: str

        :param whats_this: Chu giai "What's this".
        :type whats_this: str

        :param parent: Widget cha cua lenh.
        :type parent: QWidget

        :returns: QAction vua tao.
        :rtype: QAction
        """
        action = QAction(QIcon(icon_path), text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)
        if whats_this is not None:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.iface.addToolBarIcon(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Tao muc menu va bieu tuong tren thanh cong cu."""
        self.add_action(
            os.path.join(self.plugin_dir, 'icon.png'),
            text=self.tr(u'Check the coordinate system of map layers / '
                         u'Kiểm tra hệ tọa độ của lớp bản đồ'),
            callback=self.run,
            status_tip=self.tr(
                u'List the coordinate system of every layer in the project / '
                u'Liệt kê hệ tọa độ của mọi lớp trong dự án'),
            parent=self.iface.mainWindow())

    def unload(self):
        """Go menu va bieu tuong khoi giao dien QGIS."""
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        self.actions = []

        if self.dlg is not None:
            self.dlg.close()
            self.dlg.deleteLater()
            self.dlg = None

        if self.translator is not None:
            QCoreApplication.removeTranslator(self.translator)
            self.translator = None

    def run(self):
        """Mo hop thoai ket qua o che do khong khoa cua so chinh."""
        if self.dlg is None:
            self.dlg = CrsCheckDialog(self.iface, self.iface.mainWindow())
        self.dlg.refresh()
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
