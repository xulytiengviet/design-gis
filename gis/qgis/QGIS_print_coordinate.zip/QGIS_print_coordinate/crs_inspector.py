# -*- coding: utf-8 -*-
"""
/***************************************************************************
 checkcoordinatesys - crs_inspector
                                 A QGIS plugin
 Nhan dien va mo ta he toa do cua cac lop trong du an
 Detect and describe the coordinate reference system of project layers
                              -------------------
        begin                : 2016-10-06
        copyright            : (C) 2016 by GFD
        email                : hoa.lq@gfd.com.vn
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

Moi chuoi hien ra giao dien deu viet song ngu theo dang
"English / tieng Viet", dung dau gach cheo lam ranh gioi giua hai ngon ngu.
"""

from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import QgsProject, QgsUnitTypes

#: Bo 7 tham so chuyen doi VN-2000 -> WGS84 dung chung cho ca nuoc ("hoi nhap").
VN2000_TOWGS84_7 = (
    -191.90441429, -39.30318279, -111.45032835,
    0.00928836, -0.01975479, 0.00427372, 0.252906278,
)
#: Bo 3 tham so dich chuyen goc toa do.
VN2000_TOWGS84_3 = (-191.90441429, -39.30318279, -111.45032835)

FAMILY_VN2000 = 'vn2000'
FAMILY_UTM = 'utm'
FAMILY_GEOGRAPHIC = 'geographic'
FAMILY_PROJECTED = 'projected'
FAMILY_UNKNOWN = 'unknown'


def tr(message):
    """Dich chuoi qua Qt translation API."""
    return QCoreApplication.translate('checkcoordinatesys', message)


class CrsDescription(object):
    """Ket qua phan tich mot he toa do."""

    def __init__(self, family=FAMILY_UNKNOWN, title='', detail='', authid='',
                 units='', proj='', wkt='', valid=False):
        self.family = family
        self.title = title
        self.detail = detail
        self.authid = authid
        self.units = units
        self.proj = proj
        self.wkt = wkt
        self.valid = valid


class LayerCrsInfo(object):
    """Thong tin he toa do cua mot lop ban do."""

    def __init__(self, layer, crs_description, type_label):
        self.layer = layer
        self.layer_id = layer.id()
        self.layer_name = layer.name()
        self.crs = crs_description
        self.type_label = type_label

    @property
    def group_key(self):
        """Khoa gom nhom cac lop dung chung mot he toa do."""
        if not self.crs.valid:
            return tr(u'No CRS / Chưa có hệ tọa độ')
        label = self.crs.title
        if self.crs.detail:
            label = u'{0} — {1}'.format(label, self.crs.detail)
        return label


def _parse_proj(proj_string):
    """Tach chuoi PROJ thanh dictionary tham so."""
    params = {}
    for token in (proj_string or '').split():
        if not token.startswith('+'):
            continue
        key, separator, value = token[1:].partition('=')
        params[key] = value if separator else ''
    return params


def _as_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _as_float_list(value):
    numbers = []
    for part in (value or '').split(','):
        number = _as_float(part)
        if number is None:
            return []
        numbers.append(number)
    return numbers


def _matches(values, reference, tolerance=1e-6):
    if len(values) != len(reference):
        return False
    return all(abs(a - b) <= tolerance for a, b in zip(values, reference))


def format_meridian(longitude):
    """Dinh dang kinh tuyen truc theo do va phut, vi du 105.75 -> 105°45'."""
    sign = u'-' if longitude < 0 else u''
    longitude = abs(longitude)
    degrees = int(longitude)
    minutes = (longitude - degrees) * 60.0
    if abs(minutes - round(minutes)) < 1e-6:
        return u"{0}{1}°{2:02d}'".format(sign, degrees, int(round(minutes)))
    return u"{0}{1}°{2:05.2f}'".format(sign, degrees, minutes)


def _datum_shift_label(params):
    """Phan biet VN-2000 'noi bo' va 'hoi nhap' dua tren tham so towgs84."""
    if 'towgs84' not in params:
        return None
    values = _as_float_list(params.get('towgs84'))
    if not values:
        return tr(u'Invalid datum shift / Tham số lỗi')
    if all(abs(value) < 1e-9 for value in values):
        return tr(u'Local / Nội bộ')
    if _matches(values, VN2000_TOWGS84_7):
        return tr(u'Global 7-param / Hội nhập 7 tham số')
    if _matches(values, VN2000_TOWGS84_3):
        return tr(u'Global 3-param / Hội nhập 3 tham số')
    return tr(u'Custom datum shift / Tham số tùy chỉnh')


def _crs_proj(crs):
    """Lay chuoi PROJ, uu tien toProj() vi toProj4() da bi loai bo o QGIS 4."""
    for method_name in ('toProj', 'toProj4'):
        method = getattr(crs, method_name, None)
        if method is None:
            continue
        try:
            return method() or ''
        except (TypeError, AttributeError):
            continue
    return ''


def _crs_wkt(crs):
    try:
        return crs.toWkt() or ''
    except (TypeError, AttributeError):
        return ''


def _units_label(crs):
    try:
        return QgsUnitTypes.toString(crs.mapUnits())
    except (TypeError, AttributeError, ValueError):
        return ''


def _is_vn2000_name(text):
    normalized = (text or '').lower().replace('-', '').replace(' ', '')
    return 'vn2000' in normalized


def _describe_transverse_mercator(crs, params, description):
    """Nhan dien luoi chieu VN-2000 (TM-3 / TM-6) tu tham so PROJ."""
    scale = _as_float(params.get('k', params.get('k_0')))
    false_easting = _as_float(params.get('x_0'))
    central_meridian = _as_float(params.get('lon_0'))

    zone_width = None
    if scale is not None:
        if abs(scale - 0.9999) < 1e-9:
            zone_width = 3
        elif abs(scale - 0.9996) < 1e-9:
            zone_width = 6

    shift_label = _datum_shift_label(params)
    named_vn2000 = _is_vn2000_name(description) or _is_vn2000_name(crs.authid())
    # Dinh nghia VN-2000 tu nguoi dung luon dung x_0=500000 va he so ti le
    # 0.9999 (mui 3) hoac 0.9996 (mui 6).
    looks_like_vn2000 = named_vn2000 or (
        zone_width is not None
        and false_easting is not None
        and abs(false_easting - 500000.0) < 1e-6
    )
    if not looks_like_vn2000:
        return None

    parts = []
    if central_meridian is not None:
        # CM = central meridian, KTT = kinh tuyen truc.
        parts.append(tr(u'CM/KTT {0}').format(
            format_meridian(central_meridian)))
    if zone_width is not None:
        parts.append(tr(u'zone/múi {0}°').format(zone_width))
    if shift_label:
        parts.append(shift_label)
    elif named_vn2000:
        # PROJ 6+ khong con nhung towgs84 vao dinh nghia cua CRS chuan EPSG.
        parts.append(tr(u'datum VN-2000'))

    title = description or tr(u'VN-2000 / TM-{0}').format(zone_width or 3)
    return CrsDescription(
        family=FAMILY_VN2000,
        title=title,
        detail=u' · '.join(parts),
    )


def _describe_utm(crs, params, description):
    zone = params.get('zone')
    hemisphere = (tr(u'South / Nam') if 'south' in params
                  else tr(u'North / Bắc'))
    datum = params.get('datum') or params.get('ellps') or ''
    parts = []
    if zone:
        parts.append(tr(u'Zone/múi {0} · {1}').format(zone, hemisphere))
    if datum:
        parts.append(datum)
    title = description or (
        tr(u'UTM zone {0}').format(zone) if zone else tr(u'UTM'))
    family = FAMILY_VN2000 if _is_vn2000_name(description) else FAMILY_UTM
    return CrsDescription(family=family, title=title, detail=u' · '.join(parts))


def describe_crs(crs):
    """Phan tich mot QgsCoordinateReferenceSystem thanh mo ta de doc."""
    if crs is None or not crs.isValid():
        return CrsDescription(
            family=FAMILY_UNKNOWN,
            title=tr(u'No CRS / Chưa có hệ tọa độ'),
            detail=tr(u'CRS required / Cần gán hệ tọa độ'),
            valid=False,
        )

    proj_string = _crs_proj(crs)
    params = _parse_proj(proj_string)
    description = crs.description() or ''
    projection = params.get('proj', '')

    result = None
    if projection == 'tmerc':
        result = _describe_transverse_mercator(crs, params, description)
    elif projection == 'utm':
        result = _describe_utm(crs, params, description)

    if result is None:
        if crs.isGeographic():
            result = CrsDescription(
                family=FAMILY_GEOGRAPHIC,
                title=description or tr(u'Geographic / Tọa độ địa lý'),
                detail=tr(u'Longitude, latitude / Kinh độ, vĩ độ'),
            )
        else:
            result = CrsDescription(
                family=FAMILY_PROJECTED,
                title=description or tr(u'Projected / Tọa độ phẳng'),
                detail=params.get('proj', ''),
            )

    result.authid = crs.authid() or ''
    result.units = _units_label(crs)
    result.proj = proj_string
    result.wkt = _crs_wkt(crs)
    result.valid = True
    return result


def _layer_type_label(layer):
    """Nhan dien loai lop ma khong phu thuoc vao enum rieng cua tung phien ban."""
    try:
        from qgis.core import QgsVectorLayer, QgsWkbTypes
        if isinstance(layer, QgsVectorLayer):
            try:
                geometry = QgsWkbTypes.geometryDisplayString(
                    layer.geometryType())
                return tr(u'Vector · {0}').format(geometry)
            except (TypeError, AttributeError, ValueError):
                return tr(u'Vector')
    except ImportError:
        pass

    try:
        from qgis.core import QgsRasterLayer
        if isinstance(layer, QgsRasterLayer):
            return tr(u'Raster')
    except ImportError:
        pass

    try:
        from qgis.core import QgsMeshLayer
        if isinstance(layer, QgsMeshLayer):
            return tr(u'Mesh')
    except ImportError:
        pass

    try:
        from qgis.core import QgsPointCloudLayer
        if isinstance(layer, QgsPointCloudLayer):
            return tr(u'Point cloud')
    except ImportError:
        pass

    return tr(u'Other / Khác')


def layer_icon(layer):
    """Bieu tuong dung voi loai lop, tra ve None neu API khong san co."""
    try:
        from qgis.core import QgsIconUtils
        return QgsIconUtils.iconForLayer(layer)
    except (ImportError, AttributeError, TypeError):
        return None


def inspect_layer(layer):
    """Tao LayerCrsInfo cho mot lop."""
    return LayerCrsInfo(
        layer=layer,
        crs_description=describe_crs(layer.crs()),
        type_label=_layer_type_label(layer),
    )


def collect_layer_info(project=None):
    """Duyet cay lop theo dung thu tu hien thi trong bang chu giai."""
    project = project or QgsProject.instance()
    results = []
    for tree_layer in project.layerTreeRoot().findLayers():
        layer = tree_layer.layer()
        if layer is None:
            continue
        results.append(inspect_layer(layer))
    return results
