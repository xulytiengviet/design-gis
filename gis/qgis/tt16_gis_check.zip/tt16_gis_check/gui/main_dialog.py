"""Hộp thoại chính của plugin kiểm tra hồ sơ GIS theo TT16/2025/TT-BXD."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from qgis.core import (
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsProject,
    QgsRectangle,
    QgsSettings,
    QgsVectorLayer,
)
from qgis.gui import QgsProjectionSelectionWidget
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont, QGuiApplication
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core import report as report_module
from ..core.crs import describe_crs
from ..core.geometry_rules import ALL_RULE_CODES, GEOMETRY_RULES, RULE_BY_CODE
from ..core.models import Issue, Report, Severity
from ..core.progress import Progress
from ..core.rules import Rules
from ..core.sources import UNKNOWN_DATABASE, guess_hosogis_folder, scan
from ..core.validator import CheckOptions, Validator

SETTINGS_PREFIX = "tt16_gis_check"
# Nhóm chứa các lớp được nạp tạm từ .gdb để soi lỗi trên bản đồ.
CHECK_GROUP_NAME = "TT16 - Lớp đang kiểm tra"

AUTHOR = "Hoa Le"
AUTHOR_CREDIT = f"Created by {AUTHOR}"


def _plugin_version() -> str:
    """Đọc phiên bản từ metadata.txt để dòng tác giả không lệch với khai báo plugin."""
    metadata = Path(__file__).resolve().parent.parent / "metadata.txt"
    try:
        lines = metadata.read_text(encoding="utf-8").splitlines()
    except OSError:
        return ""
    for line in lines:
        if line.startswith("version="):
            return line.split("=", 1)[1].strip()
    return ""


PLUGIN_VERSION = _plugin_version()


def _split_codes(value: str) -> set[str]:
    return {part.strip().upper() for part in (value or "").split(",") if part.strip()}


@dataclass(frozen=True)
class Theme:
    """Bảng màu của hộp thoại, có bản riêng cho giao diện sáng và giao diện tối của QGIS."""

    severity_color: dict
    severity_background: dict
    group_header_background: QColor
    layer_node_background: QColor
    # Màu nhận diện cho từng khối tùy chọn: (màu viền/tiêu đề, màu nền nhạt).
    blocks: dict
    banner: dict
    title_color: str
    subtitle_color: str
    footer_color: str
    block_title_text: str


LIGHT_THEME = Theme(
    severity_color={
        Severity.ERROR: QColor("#c0392b"),
        Severity.WARNING: QColor("#b9770e"),
        Severity.INFO: QColor("#21618c"),
        Severity.OK: QColor("#1e8449"),
    },
    severity_background={
        Severity.ERROR: QColor("#fdecea"),
        Severity.WARNING: QColor("#fff6e5"),
        Severity.INFO: QColor("#eaf2fb"),
        Severity.OK: QColor("#ecf9f0"),
    },
    group_header_background=QColor("#e4ebf5"),
    layer_node_background=QColor("#eef2f8"),
    blocks={
        "blockSource": ("#1f6feb", "#eff5ff"),
        "blockChecks": ("#0f8a6a", "#edfaf5"),
        "blockGeometry": ("#7b3fa0", "#f7f0fc"),
        "blockOptions": ("#b06a00", "#fff7ea"),
        "blockRules": ("#475569", "#f2f5f9"),
    },
    banner={
        "neutral": "background:#eef2f8; color:#334155; border:1px solid #cbd5e1;",
        "ok": "background:#e6f7ec; color:#136c37; border:1px solid #9ad3ae;",
        "fail": "background:#fdecea; color:#a02418; border:1px solid #f0a9a1;",
    },
    title_color="#0f2c52",
    subtitle_color="#4a5b70",
    footer_color="#475569",
    block_title_text="#ffffff",
)

# Giao diện tối: nền khối tối hơn nền cửa sổ, chữ và viền sáng để đủ tương phản.
DARK_THEME = Theme(
    severity_color={
        Severity.ERROR: QColor("#ff8f85"),
        Severity.WARNING: QColor("#f3c05a"),
        Severity.INFO: QColor("#7fb8ea"),
        Severity.OK: QColor("#7fd39b"),
    },
    severity_background={
        Severity.ERROR: QColor("#3c211f"),
        Severity.WARNING: QColor("#3a2f18"),
        Severity.INFO: QColor("#1e2c3b"),
        Severity.OK: QColor("#1d3227"),
    },
    group_header_background=QColor("#2c3542"),
    layer_node_background=QColor("#252c37"),
    blocks={
        "blockSource": ("#5b9bff", "#1b2333"),
        "blockChecks": ("#35b795", "#16261f"),
        "blockGeometry": ("#b98ae0", "#241c2e"),
        "blockOptions": ("#e0a34a", "#2a2317"),
        "blockRules": ("#93a4b8", "#1f242c"),
    },
    banner={
        "neutral": "background:#232b36; color:#d3dbe5; border:1px solid #3d4756;",
        "ok": "background:#16301f; color:#8fdcab; border:1px solid #2f6b45;",
        "fail": "background:#3a1d1a; color:#ff9d92; border:1px solid #7f3b34;",
    },
    title_color="#dbe7fb",
    subtitle_color="#9aa8bb",
    footer_color="#9aa8bb",
    block_title_text="#0d1420",
)


def _is_dark_palette(widget) -> bool:
    """Giao diện tối khi màu nền cửa sổ tối hơn màu chữ."""
    palette = widget.palette()
    return palette.window().color().lightness() < palette.windowText().color().lightness()


def _dialog_stylesheet(theme: Theme) -> str:
    blocks = "".join(
        f"""
QGroupBox#{name} {{
  border: 1px solid {strong};
  border-radius: 6px;
  margin-top: 14px;
  padding: 10px 8px 8px 8px;
  background: {light};
}}
QGroupBox#{name}::title {{
  subcontrol-origin: margin;
  subcontrol-position: top left;
  left: 10px;
  padding: 2px 10px;
  color: {theme.block_title_text};
  background: {strong};
  border-radius: 4px;
}}
"""
        for name, (strong, light) in theme.blocks.items()
    )
    return (
        f"""
QGroupBox {{ font-weight: 600; }}
QLabel#headerTitle {{ font-size: 15px; font-weight: 700; color: {theme.title_color}; }}
QLabel#headerSubtitle {{ color: {theme.subtitle_color}; }}
QLabel#footerNote {{ color: {theme.footer_color}; font-weight: 600; }}
QLabel#summaryBanner {{ border-radius: 5px; padding: 7px 10px; font-weight: 700; }}
QPushButton#runButton {{ font-weight: 700; padding: 6px 18px; }}
QScrollArea#optionsScroll, QScrollArea#optionsScroll > QWidget > QWidget {{ background: transparent; }}
"""
        + blocks
    )


class TT16CheckDialog(QDialog):
    def __init__(self, iface, rules: Rules, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.rules = rules
        self.report: Report | None = None

        self.theme = DARK_THEME if _is_dark_palette(self) else LIGHT_THEME

        self.setWindowTitle("Kiểm tra hồ sơ GIS - Thông tư 16/2025/TT-BXD")
        # Tối thiểu nhỏ để kéo co được trên mọi màn hình; tab tùy chọn có vùng cuộn riêng
        # nên nội dung không bị bóp méo khi cửa sổ hẹp.
        self.setMinimumSize(680, 380)
        self.setSizeGripEnabled(True)
        self._build_ui()
        self._apply_initial_size()
        self._restore_settings()
        self._update_source_state()

    def _screen_available_size(self):
        screen = self.screen() if hasattr(self, "screen") else None
        if screen is None:
            screen = QGuiApplication.primaryScreen()
        return screen.availableGeometry() if screen is not None else None

    def _apply_initial_size(self) -> None:
        """Mở lại đúng kích thước lần trước, nếu chưa có thì chọn cỡ vừa với màn hình."""
        available = self._screen_available_size()
        max_width = available.width() - 120 if available is not None else 1040
        max_height = available.height() - 140 if available is not None else 680
        width = max(self.minimumWidth(), min(1040, max_width))
        height = max(self.minimumHeight(), min(700, max_height))
        self.resize(width, height)

        saved = QgsSettings().value(f"{SETTINGS_PREFIX}/window_size", "", type=str)
        parts = saved.split("x") if saved else []
        if len(parts) == 2 and all(part.isdigit() for part in parts):
            saved_width, saved_height = (int(part) for part in parts)
            # Bỏ qua kích thước cũ nếu màn hình hiện tại không chứa nổi cửa sổ đó.
            if saved_width <= max_width and saved_height <= max_height:
                self.resize(
                    max(self.minimumWidth(), saved_width), max(self.minimumHeight(), saved_height)
                )

    # ---------------------------------------------------------------- giao diện
    def _build_ui(self) -> None:
        self.setStyleSheet(_dialog_stylesheet(self.theme))
        layout = QVBoxLayout(self)
        layout.addWidget(self._build_header())

        tabs = QTabWidget()
        tabs.addTab(
            self._scrollable(self._build_source_tab(), "optionsScroll"),
            "1. Nguồn dữ liệu và tùy chọn",
        )
        tabs.addTab(self._build_result_tab(), "2. Kết quả kiểm tra")
        self.tabs = tabs
        layout.addWidget(tabs)

        self.progress_bar = QProgressBar()
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        self.summary_label = QLabel("Chưa thực hiện kiểm tra.")
        self.summary_label.setObjectName("summaryBanner")
        self.summary_label.setWordWrap(True)
        self._set_summary("Chưa thực hiện kiểm tra.", "neutral")
        layout.addWidget(self.summary_label)

        buttons = QDialogButtonBox()
        self.run_button = QPushButton("Kiểm tra")
        self.run_button.setObjectName("runButton")
        self.run_button.setDefault(True)
        self.export_html_button = QPushButton("Xuất báo cáo HTML")
        self.export_csv_button = QPushButton("Xuất CSV (Excel)")
        for button in (self.export_html_button, self.export_csv_button):
            button.setEnabled(False)
        buttons.addButton(self.run_button, QDialogButtonBox.ButtonRole.ActionRole)
        buttons.addButton(self.export_html_button, QDialogButtonBox.ButtonRole.ActionRole)
        buttons.addButton(self.export_csv_button, QDialogButtonBox.ButtonRole.ActionRole)
        close_button = buttons.addButton(QDialogButtonBox.StandardButton.Close)

        self.run_button.clicked.connect(self.run_check)
        self.export_html_button.clicked.connect(self.export_html)
        self.export_csv_button.clicked.connect(self.export_csv)
        close_button.clicked.connect(self.reject)

        footer = QHBoxLayout()
        version_text = f" · phiên bản {PLUGIN_VERSION}" if PLUGIN_VERSION else ""
        credit = QLabel(f"{AUTHOR_CREDIT}{version_text}")
        credit.setObjectName("footerNote")
        credit.setToolTip(f"Plugin Kiểm tra CSDL GIS{version_text} - tác giả {AUTHOR}")
        footer.addWidget(credit)
        footer.addStretch(1)
        footer.addWidget(buttons)
        layout.addLayout(footer)

    @staticmethod
    def _scrollable(page: QWidget, name: str) -> QScrollArea:
        """Bọc một trang trong vùng cuộn: thiếu chiều cao thì hiện thanh cuộn, không co nội dung."""
        area = QScrollArea()
        area.setObjectName(name)
        area.setWidget(page)
        area.setWidgetResizable(True)
        area.setFrameShape(QFrame.Shape.NoFrame)
        return area

    def _build_header(self) -> QWidget:
        header = QWidget()
        header_layout = QVBoxLayout(header)
        header_layout.setContentsMargins(2, 2, 2, 2)

        title = QLabel("Kiểm tra hồ sơ GIS quy hoạch đô thị và nông thôn")
        title.setObjectName("headerTitle")
        subtitle = QLabel("Thông tư 16/2025/TT-BXD - Phụ lục II · nguồn dữ liệu File Geodatabase (*.gdb)")
        subtitle.setObjectName("headerSubtitle")
        header_layout.addWidget(title)
        header_layout.addWidget(subtitle)
        return header

    def _set_summary(self, text: str, state: str) -> None:
        self.summary_label.setText(text)
        self.summary_label.setStyleSheet(
            self.theme.banner.get(state, self.theme.banner["neutral"])
        )

    def _build_source_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        source_box = QGroupBox("Nguồn dữ liệu cần kiểm tra (chỉ đọc File Geodatabase *.gdb)")
        source_box.setObjectName("blockSource")
        source_layout = QGridLayout(source_box)
        self.radio_folder = QRadioButton("Thư mục hồ sơ GIS (HoSoGIS) chứa các File Geodatabase")
        self.radio_file = QRadioButton("Một File Geodatabase (.gdb)")
        self.radio_folder.setChecked(True)
        for row, widget in enumerate((self.radio_folder, self.radio_file)):
            source_layout.addWidget(widget, row, 0, 1, 3)
            widget.toggled.connect(self._update_source_state)

        self.target_edit = QLineEdit()
        self.target_edit.setPlaceholderText(r"Ví dụ: D:\CSDL_QHC Thanh pho A\HoSoGIS")
        self.browse_button = QPushButton("Chọn...")
        self.browse_button.clicked.connect(self._browse)
        source_layout.addWidget(QLabel("Đường dẫn:"), 2, 0)
        source_layout.addWidget(self.target_edit, 2, 1)
        source_layout.addWidget(self.browse_button, 2, 2)
        layout.addWidget(source_box)

        checks_box = QGroupBox("Nội dung kiểm tra")
        checks_box.setObjectName("blockChecks")
        checks_layout = QGridLayout(checks_box)
        self.check_package = QCheckBox("Cấu trúc hồ sơ GIS (04 cơ sở dữ liệu, tệp tổng hợp)")
        self.check_datasets = QCheckBox("Nhóm dữ liệu chuyên đề (chủ đề / dataset)")
        self.check_layers = QCheckBox("Tên lớp dữ liệu trong từng nhóm chủ đề")
        self.check_geometry = QCheckBox("Kiểu dữ liệu hình học (_P / _L / _A)")
        self.check_fields = QCheckBox("Trường thuộc tính quy định")
        self.check_crs = QCheckBox("Hệ tọa độ (VN-2000)")
        self.check_values = QCheckBox("Giá trị thuộc tính (trường để trống, dòng không có dữ liệu)")
        for index, widget in enumerate(
            (
                self.check_package,
                self.check_datasets,
                self.check_layers,
                self.check_geometry,
                self.check_fields,
                self.check_crs,
                self.check_values,
            )
        ):
            widget.setChecked(True)
            checks_layout.addWidget(widget, index // 2, index % 2)
        layout.addWidget(checks_box)
        layout.addWidget(self._build_geometry_box())

        options_box = QGroupBox("Mức độ kiểm tra")
        options_box.setObjectName("blockOptions")
        options_layout = QGridLayout(options_box)
        options_layout.addWidget(QLabel("Báo lớp dữ liệu còn thiếu:"), 0, 0)
        self.missing_scope_combo = QComboBox()
        self.missing_scope_combo.addItem(
            "Chỉ trong các nhóm chuyên đề đã có dữ liệu (khuyến nghị)", "used"
        )
        self.missing_scope_combo.addItem("Toàn bộ lớp theo quy định", "all")
        options_layout.addWidget(self.missing_scope_combo, 0, 1)

        self.strict_check = QCheckBox("Chế độ nghiêm ngặt: coi nhóm/lớp còn thiếu là lỗi")
        options_layout.addWidget(self.strict_check, 1, 0, 1, 2)
        self.extra_layers_check = QCheckBox("Báo các lớp phát sinh ngoài quy định")
        self.extra_layers_check.setChecked(True)
        options_layout.addWidget(self.extra_layers_check, 2, 0, 1, 2)
        self.field_length_check = QCheckBox("Coi độ dài trường không đủ là lỗi")
        options_layout.addWidget(self.field_length_check, 3, 0, 1, 2)
        self.report_passed_check = QCheckBox("Liệt kê cả những nội dung kiểm tra đã đạt")
        self.report_passed_check.setChecked(True)
        options_layout.addWidget(self.report_passed_check, 5, 0, 1, 2)

        self.expected_crs_check = QCheckBox("Bắt buộc đúng một hệ tọa độ cụ thể:")
        self.expected_crs_widget = QgsProjectionSelectionWidget()
        self.expected_crs_widget.setEnabled(False)
        self.expected_crs_check.toggled.connect(self.expected_crs_widget.setEnabled)
        options_layout.addWidget(self.expected_crs_check, 4, 0)
        options_layout.addWidget(self.expected_crs_widget, 4, 1)

        options_layout.addWidget(QLabel("Số đối tượng đọc mỗi lớp:"), 6, 0)
        self.max_features_spin = QSpinBox()
        self.max_features_spin.setRange(0, 100_000_000)
        self.max_features_spin.setSingleStep(1000)
        self.max_features_spin.setValue(0)
        self.max_features_spin.setSpecialValueText("Toàn bộ lớp (không giới hạn)")
        self.max_features_spin.setToolTip(
            "Mặc định kiểm tra toàn bộ đối tượng của lớp. Đặt một con số nếu muốn dừng sớm "
            "để chạy nhanh trên dữ liệu rất lớn."
        )
        options_layout.addWidget(self.max_features_spin, 6, 1)
        layout.addWidget(options_box)

        rules_box = QGroupBox("Bộ quy tắc")
        rules_box.setObjectName("blockRules")
        rules_layout = QHBoxLayout(rules_box)
        self.rules_label = QLabel()
        self.rules_label.setWordWrap(True)
        rules_layout.addWidget(self.rules_label, 1)
        layout.addWidget(rules_box)
        self._refresh_rules_label()

        layout.addStretch(1)
        return page

    def _build_geometry_box(self) -> QGroupBox:
        """Danh sách quy tắc hình học/topology, bật tắt theo từng mã luật."""
        box = QGroupBox("Quy tắc kiểm tra hình học, topology (G/P/L/A)")
        box.setObjectName("blockGeometry")
        box.setCheckable(True)
        box.setChecked(True)
        box.setToolTip(
            "Bỏ chọn cả nhóm để không kiểm tra hình học. "
            "Mỗi vi phạm được liệt kê theo từng đối tượng và phóng tới được trên bản đồ."
        )
        grid = QGridLayout(box)

        self.rule_checks: dict[str, QCheckBox] = {}
        for index, rule in enumerate(GEOMETRY_RULES):
            check = QCheckBox(rule.label)
            check.setChecked(rule.default_enabled)
            scope = (
                "mọi kiểu hình học"
                if not rule.geometries
                else "chỉ lớp " + "/".join(f"_{code}" for code in rule.geometries)
            )
            check.setToolTip(f"{rule.severity.label} - {scope}. {rule.hint}")
            # Màu chữ theo mức độ để nhìn ra ngay luật nào báo lỗi, luật nào chỉ cảnh báo.
            check.setStyleSheet(f"color: {self.theme.severity_color[rule.severity].name()};")
            grid.addWidget(check, index // 2, index % 2)
            self.rule_checks[rule.code] = check

        row = (len(GEOMETRY_RULES) + 1) // 2
        select_all = QPushButton("Chọn tất cả")
        select_all.clicked.connect(lambda: self._set_all_rules(True))
        clear_all = QPushButton("Bỏ chọn tất cả")
        clear_all.clicked.connect(lambda: self._set_all_rules(False))
        buttons = QHBoxLayout()
        buttons.addWidget(select_all)
        buttons.addWidget(clear_all)
        buttons.addStretch(1)
        grid.addLayout(buttons, row, 0, 1, 2)

        tolerance = QHBoxLayout()
        self.min_length_spin = QDoubleSpinBox()
        self.min_length_spin.setDecimals(3)
        self.min_length_spin.setRange(0.0, 10000.0)
        self.min_length_spin.setValue(0.1)
        self.min_overlap_spin = QDoubleSpinBox()
        self.min_overlap_spin.setDecimals(3)
        self.min_overlap_spin.setRange(0.0, 1000000.0)
        self.min_overlap_spin.setValue(0.01)
        self.min_gap_spin = QDoubleSpinBox()
        self.min_gap_spin.setDecimals(3)
        self.min_gap_spin.setRange(0.0, 1000000.0)
        self.min_gap_spin.setValue(0.01)
        for label, widget in (
            ("Độ dài tối thiểu (L04):", self.min_length_spin),
            ("Diện tích chồng đè tối thiểu (A01):", self.min_overlap_spin),
            ("Diện tích khe hở tối thiểu (A03):", self.min_gap_spin),
        ):
            tolerance.addWidget(QLabel(label))
            tolerance.addWidget(widget)
        tolerance.addStretch(1)
        grid.addLayout(tolerance, row + 1, 0, 1, 2)
        note = QLabel("Dung sai tính theo đơn vị hệ tọa độ của lớp (mét với VN-2000 múi 3°/6°).")
        note.setWordWrap(True)
        grid.addWidget(note, row + 2, 0, 1, 2)
        self.geometry_box = box
        return box

    def _set_all_rules(self, checked: bool) -> None:
        for check in self.rule_checks.values():
            check.setChecked(checked)

    def _build_result_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)

        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Hiện:"))
        self.filter_error = QCheckBox("Lỗi")
        self.filter_warning = QCheckBox("Cảnh báo")
        self.filter_info = QCheckBox("Thông tin")
        self.filter_pass = QCheckBox("Đạt")
        self.filter_counters: dict[Severity, QCheckBox] = {
            Severity.ERROR: self.filter_error,
            Severity.WARNING: self.filter_warning,
            Severity.INFO: self.filter_info,
            Severity.OK: self.filter_pass,
        }
        for severity, widget in self.filter_counters.items():
            widget.setChecked(True)
            widget.toggled.connect(self._apply_filter)
            widget.setStyleSheet(
                f"QCheckBox {{ color: {self.theme.severity_color[severity].name()}; font-weight: 600; "
                f"background: {self.theme.severity_background[severity].name()}; "
                "border-radius: 4px; padding: 3px 8px; }"
            )
            filter_layout.addWidget(widget)
        filter_layout.addSpacing(16)
        filter_layout.addWidget(QLabel("Tìm:"))
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Lọc theo tên lớp, nhóm dữ liệu, nội dung...")
        self.search_edit.textChanged.connect(self._apply_filter)
        filter_layout.addWidget(self.search_edit, 1)
        layout.addLayout(filter_layout)

        splitter = QSplitter(Qt.Orientation.Vertical)

        self.issue_tree = QTreeWidget()
        self.issue_tree.setColumnCount(5)
        self.issue_tree.setHeaderLabels(
            [
                "Nhóm kiểm tra / Lớp dữ liệu / Quy tắc / Đối tượng",
                "Mức độ",
                "FID",
                "Nội dung",
                "Gợi ý khắc phục",
            ]
        )
        # Nền của từng dòng đã mã hóa theo mức độ nên không dùng thêm màu dòng chẵn/lẻ.
        self.issue_tree.setAlternatingRowColors(False)
        self.issue_tree.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.issue_tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.issue_tree.header().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.issue_tree.setColumnWidth(0, 320)
        self.issue_tree.setColumnWidth(1, 80)
        self.issue_tree.setColumnWidth(2, 50)
        self.issue_tree.setColumnWidth(4, 260)
        self.issue_tree.itemDoubleClicked.connect(self._on_issue_double_clicked)
        self.issue_tree.itemSelectionChanged.connect(self._update_locate_buttons)
        splitter.addWidget(self.issue_tree)

        self.inventory_tree = QTreeWidget()
        self.inventory_tree.setColumnCount(5)
        self.inventory_tree.setHeaderLabels(
            ["Cơ sở dữ liệu / Nhóm dữ liệu / Lớp", "Kiểu", "Hệ tọa độ", "Số trường", "Số đối tượng"]
        )
        self.inventory_tree.setColumnWidth(0, 340)
        splitter.addWidget(self.inventory_tree)
        splitter.setSizes([420, 200])
        layout.addWidget(splitter)

        locate_layout = QHBoxLayout()
        self.zoom_button = QPushButton("Phóng tới đối tượng lỗi")
        self.zoom_button.setToolTip(
            "Nạp lớp từ .gdb vào project (nếu chưa có), chọn và phóng tới đối tượng lỗi trên bản đồ.\n"
            "Có thể bấm đúp vào dòng lỗi để phóng nhanh. Chọn dòng tên lớp để phóng tới toàn bộ lỗi của lớp."
        )
        self.attribute_button = QPushButton("Mở bảng thuộc tính của lớp")
        for button in (self.zoom_button, self.attribute_button):
            button.setEnabled(False)
            locate_layout.addWidget(button)
        self.zoom_button.clicked.connect(self._zoom_to_selected_issue)
        self.attribute_button.clicked.connect(self._open_attribute_table)
        locate_layout.addStretch(1)
        layout.addLayout(locate_layout)
        return page

    # ------------------------------------------------------------------ tiện ích
    def _refresh_rules_label(self) -> None:
        self.rules_label.setText(
            f"{self.rules.standard} - phiên bản {self.rules.rules_version}: "
            f"{len(self.rules.databases)} cơ sở dữ liệu, "
            f"{sum(len(db.datasets) for db in self.rules.databases)} nhóm dữ liệu, "
            f"{sum(len(db.layer_rules()) for db in self.rules.databases)} lớp dữ liệu, "
            f"{len(self.rules.required_fields)} trường bắt buộc."
        )

    def _update_source_state(self) -> None:
        self.check_package.setEnabled(not self.radio_file.isChecked())
        self.target_edit.setPlaceholderText(
            r"Ví dụ: D:\CSDL_QHC Thanh pho A\HoSoGIS"
            if self.radio_folder.isChecked()
            else r"Ví dụ: D:\CSDL_QHC Thanh pho A\HoSoGIS\HienTrang.gdb"
        )
        if self.radio_folder.isChecked() and not self.target_edit.text():
            guessed = guess_hosogis_folder(QgsProject.instance())
            if guessed:
                self.target_edit.setText(guessed)

    def _browse(self) -> None:
        """File Geodatabase là một thư mục *.gdb nên cả hai trường hợp đều chọn thư mục."""
        settings = QgsSettings()
        last = settings.value(f"{SETTINGS_PREFIX}/last_dir", "")
        title = (
            "Chọn thư mục hồ sơ GIS (chứa các *.gdb)"
            if self.radio_folder.isChecked()
            else "Chọn File Geodatabase (*.gdb)"
        )
        path = QFileDialog.getExistingDirectory(self, title, last)
        if not path:
            return
        if self.radio_file.isChecked() and Path(path).suffix.lower() != ".gdb":
            QMessageBox.warning(
                self,
                "Không phải File Geodatabase",
                f"'{Path(path).name}' không có phần mở rộng .gdb.\n"
                "Plugin chỉ đọc dữ liệu từ File Geodatabase (*.gdb).",
            )
            return
        self.target_edit.setText(path)
        settings.setValue(f"{SETTINGS_PREFIX}/last_dir", str(Path(path).parent))

    def _collect_options(self) -> CheckOptions:
        return CheckOptions(
            check_package=self.check_package.isChecked() and self.check_package.isEnabled(),
            check_datasets=self.check_datasets.isChecked(),
            check_layers=self.check_layers.isChecked(),
            check_geometry=self.check_geometry.isChecked(),
            check_shape=self.geometry_box.isChecked(),
            geometry_rules=self._selected_rule_codes(),
            min_line_length=self.min_length_spin.value(),
            min_overlap_area=self.min_overlap_spin.value(),
            min_gap_area=self.min_gap_spin.value(),
            check_fields=self.check_fields.isChecked(),
            check_values=self.check_values.isChecked(),
            check_crs=self.check_crs.isChecked(),
            report_extra_layers=self.extra_layers_check.isChecked(),
            report_passed=self.report_passed_check.isChecked(),
            missing_layers_scope=self.missing_scope_combo.currentData(),
            strict=self.strict_check.isChecked(),
            max_features=self.max_features_spin.value(),
            field_length_as_error=self.field_length_check.isChecked(),
            expected_crs_authid=(
                self.expected_crs_widget.crs().authid() if self.expected_crs_check.isChecked() else ""
            ),
        )

    def _selected_rule_codes(self) -> set[str]:
        return {code for code, check in self.rule_checks.items() if check.isChecked()}

    def _source_kind(self) -> str:
        return "folder" if self.radio_folder.isChecked() else "file"

    # ------------------------------------------------------------- thanh tiến trình
    def _begin_progress(self) -> None:
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("Đang chuẩn bị...")
        self.progress_bar.setVisible(True)
        for button in (self.run_button, self.export_html_button, self.export_csv_button):
            button.setEnabled(False)

    def _end_progress(self) -> None:
        self.progress_bar.setVisible(False)
        self.run_button.setEnabled(True)

    def _on_progress(self, message: str, done: int, total: int) -> None:
        """Cập nhật thanh tiến trình; total = 0 nghĩa là chưa biết tổng nên chạy vô định."""
        # Ký tự '%' trong thông điệp sẽ bị QProgressBar hiểu là mã định dạng.
        label = message.replace("%", " phần trăm")
        if total > 0:
            if self.progress_bar.maximum() != total:
                self.progress_bar.setRange(0, total)
            self.progress_bar.setValue(min(done, total))
            self.progress_bar.setFormat(f"{label} ({done}/{total})")
        else:
            self.progress_bar.setRange(0, 0)
            self.progress_bar.setFormat(label)
        QApplication.processEvents()

    # -------------------------------------------------------------- chạy kiểm tra
    def run_check(self) -> None:
        source_kind = self._source_kind()
        target = self.target_edit.text().strip()
        if not target:
            QMessageBox.warning(self, "Thiếu thông tin", "Vui lòng chọn đường dẫn cần kiểm tra.")
            return

        options = self._collect_options()
        progress = Progress(on_step=self._on_progress)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        self._begin_progress()
        self._set_summary("Đang đọc dữ liệu và kiểm tra...", "neutral")
        QApplication.processEvents()
        try:
            scan_result = scan(
                source_kind,
                target,
                self.rules,
                count_features=options.needs_features,
                progress=progress,
            )
            self.report = Validator(self.rules, options).run(scan_result, progress=progress)
        except Exception as error:
            QApplication.restoreOverrideCursor()
            self._end_progress()
            self._set_summary(f"Kiểm tra thất bại: {error}", "fail")
            QMessageBox.critical(self, "Lỗi khi kiểm tra", str(error))
            return
        finally:
            QApplication.restoreOverrideCursor()
            self._end_progress()

        self._populate_results()
        self.tabs.setCurrentIndex(1)
        for button in (self.export_html_button, self.export_csv_button):
            button.setEnabled(True)
        self._save_settings()

    def _populate_results(self) -> None:
        report = self.report
        if report is None:
            return

        self.issue_tree.clear()
        grouped: dict[str, list] = {}
        for issue in report.sorted_issues():
            grouped.setdefault(issue.group.value, []).append(issue)

        for group_name, issues in grouped.items():
            errors = sum(1 for issue in issues if issue.severity is Severity.ERROR)
            warnings = sum(1 for issue in issues if issue.severity is Severity.WARNING)
            passed = sum(1 for issue in issues if issue.severity is Severity.OK)
            verdict = "Đạt" if errors == 0 and warnings == 0 else f"{errors} lỗi / {warnings} cảnh báo"
            parent = QTreeWidgetItem(
                [
                    f"{group_name} ({len(issues)})",
                    verdict,
                    "",
                    f"{passed} nội dung đạt" if passed else "",
                    "",
                ]
            )
            group_passed = errors == 0 and warnings == 0
            group_severity = Severity.OK if group_passed else Severity.ERROR if errors else Severity.WARNING
            parent.setForeground(0, self.theme.severity_color[group_severity])
            parent.setForeground(1, self.theme.severity_color[group_severity])
            font = parent.font(0)
            font.setBold(True)
            for column in range(self.issue_tree.columnCount()):
                parent.setFont(column, font)
                parent.setBackground(column, self.theme.group_header_background)

            # Lỗi gắn với đối tượng cụ thể xếp theo lớp dữ liệu, rồi theo mã quy tắc hình học.
            layer_nodes: dict[str, QTreeWidgetItem] = {}
            rule_nodes: dict[tuple[str, str], QTreeWidgetItem] = {}
            layer_counts: dict[str, int] = {}
            for issue in (item for item in issues if item.is_feature_issue):
                layer_node = layer_nodes.get(issue.layer_key)
                if layer_node is None:
                    layer_node = QTreeWidgetItem([issue.layer_key, "", "", "", ""])
                    node_font = layer_node.font(0)
                    node_font.setBold(True)
                    layer_node.setFont(0, node_font)
                    for column in range(self.issue_tree.columnCount()):
                        layer_node.setBackground(column, self.theme.layer_node_background)
                    parent.addChild(layer_node)
                    layer_nodes[issue.layer_key] = layer_node
                layer_counts[issue.layer_key] = layer_counts.get(issue.layer_key, 0) + 1

                target = layer_node
                if issue.rule_code:
                    key = (issue.layer_key, issue.rule_code)
                    target = rule_nodes.get(key)
                    if target is None:
                        rule = RULE_BY_CODE.get(issue.rule_code)
                        target = QTreeWidgetItem(
                            [
                                f"{issue.rule_code} - {rule.name}" if rule else issue.rule_code,
                                "",
                                "",
                                rule.english if rule else "",
                                rule.hint if rule else "",
                            ]
                        )
                        layer_node.addChild(target)
                        rule_nodes[key] = target
                        target.setExpanded(True)
                label = f"FID {issue.feature_id}" if issue.feature_id >= 0 else "Vị trí lỗi"
                target.addChild(self._issue_item(issue, label=label))

            for key, node in rule_nodes.items():
                severity = RULE_BY_CODE[key[1]].severity if key[1] in RULE_BY_CODE else Severity.ERROR
                node.setText(1, f"{node.childCount()} vi phạm")
                node.setForeground(1, self.theme.severity_color[severity])
                rule_font = node.font(0)
                rule_font.setBold(True)
                node.setFont(0, rule_font)
                node.setForeground(0, self.theme.severity_color[severity])
                for column in range(self.issue_tree.columnCount()):
                    node.setBackground(column, self.theme.severity_background[severity])

            for layer_key, node in layer_nodes.items():
                errors_here = sum(
                    1
                    for issue in issues
                    if issue.is_feature_issue
                    and issue.layer_key == layer_key
                    and issue.severity is Severity.ERROR
                )
                node.setText(0, f"{layer_key} - {layer_counts.get(layer_key, 0)} vi phạm")
                node.setText(1, f"{errors_here} lỗi" if errors_here else "cảnh báo")
                node.setForeground(
                    1, self.theme.severity_color[Severity.ERROR if errors_here else Severity.WARNING]
                )
                node.setExpanded(True)

            # Dòng tổng hợp của lớp nằm cùng nhánh với các đối tượng lỗi của lớp đó.
            for issue in (item for item in issues if not item.is_feature_issue):
                node = layer_nodes.get(issue.layer_key, parent)
                node.addChild(self._issue_item(issue))

            self.issue_tree.addTopLevelItem(parent)
            parent.setExpanded(errors > 0 or warnings > 0)

        state = "ĐẠT - không phát hiện lỗi" if report.is_passed else "CHƯA ĐẠT"
        self._set_summary(
            f"{state}. {report.summary_text()}. Nguồn: {report.scan.source_label}",
            "ok" if report.is_passed else "fail",
        )
        self._refresh_filter_counts(report)
        self._populate_inventory()
        self._apply_filter()
        self._update_locate_buttons()

    def _refresh_filter_counts(self, report: Report) -> None:
        labels = {
            Severity.ERROR: "Lỗi",
            Severity.WARNING: "Cảnh báo",
            Severity.INFO: "Thông tin",
            Severity.OK: "Đạt",
        }
        for severity, widget in self.filter_counters.items():
            widget.setText(f"{labels[severity]} ({report.count(severity)})")

    def _issue_item(self, issue: Issue, label: str = "") -> QTreeWidgetItem:
        item = QTreeWidgetItem(
            [
                label or issue.target,
                issue.severity.label,
                "" if issue.feature_id < 0 else str(issue.feature_id),
                issue.message,
                issue.hint,
            ]
        )
        item.setForeground(1, self.theme.severity_color[issue.severity])
        for column in range(self.issue_tree.columnCount()):
            item.setBackground(column, self.theme.severity_background[issue.severity])
        if issue.severity is Severity.ERROR:
            item.setForeground(0, self.theme.severity_color[Severity.ERROR])
            message_font = item.font(3)
            message_font.setBold(True)
            item.setFont(3, message_font)
        item.setToolTip(3, issue.message)
        item.setToolTip(4, issue.hint)
        item.setData(0, Qt.ItemDataRole.UserRole, issue)
        return item

    def _populate_inventory(self) -> None:
        report = self.report
        self.inventory_tree.clear()
        if report is None:
            return

        # Đánh dấu ngay trên danh mục những lớp đang có lỗi / có cảnh báo.
        severity_by_layer: dict[str, Severity] = {}
        for issue in report.issues:
            if not issue.layer or issue.severity not in (Severity.ERROR, Severity.WARNING):
                continue
            current = severity_by_layer.get(issue.layer_key)
            if current is not Severity.ERROR:
                severity_by_layer[issue.layer_key] = issue.severity

        for database in report.scan.databases:
            label = database.code if database.code != UNKNOWN_DATABASE else "Không xác định CSDL"
            db_item = QTreeWidgetItem([f"{label} - {database.path}", "", "", "", ""])
            font = db_item.font(0)
            font.setBold(True)
            db_item.setFont(0, font)
            for column in range(self.inventory_tree.columnCount()):
                db_item.setBackground(column, self.theme.group_header_background)

            by_dataset: dict[str, list] = {}
            for layer in database.layers:
                by_dataset.setdefault(layer.dataset or "(chưa xác định nhóm)", []).append(layer)

            for dataset_name, layers in sorted(by_dataset.items()):
                dataset_item = QTreeWidgetItem([f"{dataset_name} ({len(layers)} lớp)", "", "", "", ""])
                for column in range(self.inventory_tree.columnCount()):
                    dataset_item.setBackground(column, self.theme.layer_node_background)
                for layer in sorted(layers, key=lambda item: item.name):
                    layer_item = QTreeWidgetItem(
                        [
                            layer.name,
                            self.rules.geometry_label(layer.geometry) if layer.geometry else layer.geometry_label,
                            describe_crs(layer),
                            str(len(layer.fields)),
                            "" if layer.feature_count < 0 else str(layer.feature_count),
                        ]
                    )
                    severity = severity_by_layer.get(
                        " / ".join(part for part in (layer.database, layer.dataset, layer.name) if part)
                    )
                    if severity is not None:
                        layer_item.setForeground(0, self.theme.severity_color[severity])
                        for column in range(self.inventory_tree.columnCount()):
                            layer_item.setBackground(column, self.theme.severity_background[severity])
                    dataset_item.addChild(layer_item)
                db_item.addChild(dataset_item)
            self.inventory_tree.addTopLevelItem(db_item)
            db_item.setExpanded(True)

    def _apply_filter(self) -> None:
        allowed = set()
        if self.filter_error.isChecked():
            allowed.add(Severity.ERROR)
        if self.filter_warning.isChecked():
            allowed.add(Severity.WARNING)
        if self.filter_info.isChecked():
            allowed.add(Severity.INFO)
        if self.filter_pass.isChecked():
            allowed.add(Severity.OK)
        needle = self.search_edit.text().strip().lower()

        for index in range(self.issue_tree.topLevelItemCount()):
            parent = self.issue_tree.topLevelItem(index)
            parent.setHidden(not self._filter_item(parent, allowed, needle))

    def _filter_item(self, item: QTreeWidgetItem, allowed: set, needle: str) -> bool:
        """Ẩn/hiện đệ quy; trả về True nếu bản thân hoặc nhánh con còn nội dung hiển thị."""
        issue = item.data(0, Qt.ItemDataRole.UserRole)
        if issue is not None:
            match = issue.severity in allowed
            if match and needle:
                haystack = " ".join(
                    [issue.target, issue.message, issue.hint, issue.group.value]
                ).lower()
                match = needle in haystack
            item.setHidden(not match)
            return match

        visible = 0
        for index in range(item.childCount()):
            visible += int(self._filter_item(item.child(index), allowed, needle))
        item.setHidden(visible == 0)
        return visible > 0

    # ------------------------------------------------- định vị lỗi trên bản đồ
    def _selected_issues(self) -> list[Issue]:
        """Các phát hiện gắn với đối tượng của dòng đang chọn (dòng lớp trả về cả nhánh con)."""
        items = self.issue_tree.selectedItems()
        if not items:
            return []
        item = items[0]
        issue = item.data(0, Qt.ItemDataRole.UserRole)
        if issue is not None:
            return [issue] if issue.can_locate else []
        collected: list[Issue] = []
        for index in range(item.childCount()):
            child = item.child(index)
            if child.isHidden():
                continue
            child_issue = child.data(0, Qt.ItemDataRole.UserRole)
            if child_issue is not None and child_issue.can_locate:
                collected.append(child_issue)
        return collected

    def _update_locate_buttons(self) -> None:
        issues = self._selected_issues()
        self.zoom_button.setEnabled(bool(issues) and self.iface is not None)
        self.attribute_button.setEnabled(bool(issues) and self.iface is not None)

    def _on_issue_double_clicked(self, item: QTreeWidgetItem, column: int) -> None:
        self._zoom_to_selected_issue()

    def _resolve_map_layer(self, issue: Issue) -> QgsVectorLayer | None:
        """Tìm lớp trong project, nếu chưa có thì nạp lớp từ .gdb vào nhóm kiểm tra."""
        project = QgsProject.instance()
        if issue.layer_id:
            existing = project.mapLayer(issue.layer_id)
            if existing is not None:
                return existing
        if not issue.layer_uri:
            return None
        for layer in project.mapLayers().values():
            if isinstance(layer, QgsVectorLayer) and layer.source() == issue.layer_uri:
                return layer

        layer = QgsVectorLayer(issue.layer_uri, issue.layer or "Lớp kiểm tra", "ogr")
        if not layer.isValid():
            return None
        root = project.layerTreeRoot()
        group = root.findGroup(CHECK_GROUP_NAME) or root.insertGroup(0, CHECK_GROUP_NAME)
        project.addMapLayer(layer, False)
        group.addLayer(layer)
        return layer

    def _prepare_layer(self, issues: list[Issue]) -> tuple[QgsVectorLayer | None, list[int]]:
        if not issues or self.iface is None:
            return None, []
        layer = self._resolve_map_layer(issues[0])
        if layer is None:
            QMessageBox.warning(
                self,
                "Không mở được lớp",
                "Không nạp được lớp dữ liệu để phóng tới đối tượng lỗi:\n"
                f"{issues[0].layer_uri or issues[0].layer}",
            )
            return None, []
        feature_ids = [issue.feature_id for issue in issues if issue.feature_id >= 0]
        feature_ids.extend(
            issue.other_feature_id
            for issue in issues
            if issue.other_feature_id >= 0 and issue.other_feature_id not in feature_ids
        )
        layer.selectByIds(feature_ids)
        self.iface.setActiveLayer(layer)
        return layer, feature_ids

    def _zoom_to_selected_issue(self) -> None:
        issues = self._selected_issues()
        layer, feature_ids = self._prepare_layer(issues)
        if layer is None:
            return

        rect = self._issues_extent(layer, issues)
        if rect is None:
            self.iface.messageBar().pushWarning(
                "Kiểm tra CSDL GIS",
                f"Đối tượng FID {', '.join(str(fid) for fid in feature_ids)} của lớp {layer.name()} "
                "không có hình học nên không phóng tới được - đã chọn sẵn trong bảng thuộc tính.",
            )
            self.iface.showAttributeTable(layer)
            return

        canvas = self.iface.mapCanvas()
        canvas.setExtent(rect)
        canvas.refresh()
        if hasattr(canvas, "flashFeatureIds"):
            canvas.flashFeatureIds(layer, feature_ids)

    def _issues_extent(self, layer: QgsVectorLayer, issues: list[Issue]) -> QgsRectangle | None:
        """Khung bao của các đối tượng lỗi, đã chuyển về hệ tọa độ bản đồ."""
        rect: QgsRectangle | None = None
        for issue in issues:
            box = None
            # Khung bao lưu trong phát hiện thường hẹp hơn (phần chồng đè, khe hở) nên ưu tiên dùng.
            if issue.bbox:
                box = QgsRectangle(*issue.bbox)
            elif issue.feature_id >= 0:
                feature = next(
                    layer.getFeatures(QgsFeatureRequest().setFilterFid(issue.feature_id)), None
                )
                if feature is not None and feature.hasGeometry():
                    box = feature.geometry().boundingBox()
            if box is None or box.isNull():
                continue
            rect = QgsRectangle(box) if rect is None else rect
            rect.combineExtentWith(box)
        if rect is None:
            return None

        canvas_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        if layer.crs().isValid() and canvas_crs.isValid() and layer.crs() != canvas_crs:
            transform = QgsCoordinateTransform(layer.crs(), canvas_crs, QgsProject.instance())
            rect = transform.transformBoundingBox(rect)
        # Điểm hoặc vùng lỗi rất nhỏ: mở rộng khung nhìn để còn thấy được trên bản đồ.
        buffer = 0.0005 if canvas_crs.isGeographic() else 50.0
        if rect.width() < buffer and rect.height() < buffer:
            rect.grow(buffer)
        else:
            rect.scale(1.3)
        return rect

    def _open_attribute_table(self) -> None:
        issues = self._selected_issues()
        layer, _ = self._prepare_layer(issues)
        if layer is not None:
            self.iface.showAttributeTable(layer)

    # ------------------------------------------------------------------ xuất báo cáo
    def _export_path(self, suffix: str, filter_text: str) -> str:
        default_name = "BaoCao_KiemTra_HoSoGIS"
        if self.report and self.report.scan.root_path:
            default_name = f"{default_name}_{Path(self.report.scan.root_path).name}"
        start_dir = str(Path(self.report.scan.root_path) / f"{default_name}{suffix}") if self.report else ""
        path, _ = QFileDialog.getSaveFileName(self, "Lưu báo cáo", start_dir, filter_text)
        return path

    def export_html(self) -> None:
        if not self.report:
            return
        path = self._export_path(".html", "HTML (*.html)")
        if not path:
            return
        output = report_module.write_html(self.report, path)
        self._notify_export(output)

    def export_csv(self) -> None:
        if not self.report:
            return
        path = self._export_path(".csv", "CSV (*.csv)")
        if not path:
            return
        output = report_module.write_csv(self.report, path)
        self._notify_export(output)

    def _notify_export(self, path: Path) -> None:
        self.iface.messageBar().pushSuccess("Kiểm tra CSDL GIS", f"Đã lưu báo cáo: {path}")

    # ------------------------------------------------------------------ lưu cấu hình
    def _save_settings(self) -> None:
        settings = QgsSettings()
        settings.setValue(f"{SETTINGS_PREFIX}/source_kind", self._source_kind())
        settings.setValue(f"{SETTINGS_PREFIX}/target", self.target_edit.text())
        settings.setValue(f"{SETTINGS_PREFIX}/missing_scope", self.missing_scope_combo.currentData())
        settings.setValue(f"{SETTINGS_PREFIX}/strict", self.strict_check.isChecked())
        settings.setValue(f"{SETTINGS_PREFIX}/check_values", self.check_values.isChecked())
        settings.setValue(f"{SETTINGS_PREFIX}/check_shape", self.geometry_box.isChecked())
        settings.setValue(
            f"{SETTINGS_PREFIX}/geometry_rules", ",".join(sorted(self._selected_rule_codes()))
        )
        settings.setValue(
            f"{SETTINGS_PREFIX}/geometry_rules_known", ",".join(sorted(ALL_RULE_CODES))
        )
        settings.setValue(f"{SETTINGS_PREFIX}/min_line_length", self.min_length_spin.value())
        settings.setValue(f"{SETTINGS_PREFIX}/min_overlap_area", self.min_overlap_spin.value())
        settings.setValue(f"{SETTINGS_PREFIX}/min_gap_area", self.min_gap_spin.value())
        settings.setValue(f"{SETTINGS_PREFIX}/report_passed", self.report_passed_check.isChecked())
        settings.setValue(f"{SETTINGS_PREFIX}/max_features", self.max_features_spin.value())
        settings.setValue(f"{SETTINGS_PREFIX}/window_size", f"{self.width()}x{self.height()}")

    def closeEvent(self, event) -> None:
        """Nhớ kích thước cửa sổ để lần sau mở lại đúng cỡ người dùng đã kéo."""
        QgsSettings().setValue(f"{SETTINGS_PREFIX}/window_size", f"{self.width()}x{self.height()}")
        super().closeEvent(event)

    def _restore_settings(self) -> None:
        settings = QgsSettings()
        source_kind = settings.value(f"{SETTINGS_PREFIX}/source_kind", "folder")
        {"folder": self.radio_folder, "file": self.radio_file}.get(
            source_kind, self.radio_folder
        ).setChecked(True)
        self.target_edit.setText(settings.value(f"{SETTINGS_PREFIX}/target", ""))
        scope_index = self.missing_scope_combo.findData(
            settings.value(f"{SETTINGS_PREFIX}/missing_scope", "used")
        )
        if scope_index >= 0:
            self.missing_scope_combo.setCurrentIndex(scope_index)
        self.strict_check.setChecked(settings.value(f"{SETTINGS_PREFIX}/strict", False, type=bool))
        self.check_values.setChecked(settings.value(f"{SETTINGS_PREFIX}/check_values", True, type=bool))
        self.geometry_box.setChecked(settings.value(f"{SETTINGS_PREFIX}/check_shape", True, type=bool))
        known = settings.value(f"{SETTINGS_PREFIX}/geometry_rules_known", "", type=str)
        if known:
            enabled = _split_codes(settings.value(f"{SETTINGS_PREFIX}/geometry_rules", "", type=str))
            # Quy tắc mới thêm vào sau lần lưu cấu hình vẫn giữ trạng thái mặc định.
            for code in _split_codes(known):
                check = self.rule_checks.get(code)
                if check is not None:
                    check.setChecked(code in enabled)
        self.min_length_spin.setValue(
            settings.value(f"{SETTINGS_PREFIX}/min_line_length", 0.1, type=float)
        )
        self.min_overlap_spin.setValue(
            settings.value(f"{SETTINGS_PREFIX}/min_overlap_area", 0.01, type=float)
        )
        self.min_gap_spin.setValue(
            settings.value(f"{SETTINGS_PREFIX}/min_gap_area", 0.01, type=float)
        )
        self.report_passed_check.setChecked(
            settings.value(f"{SETTINGS_PREFIX}/report_passed", True, type=bool)
        )
        self.max_features_spin.setValue(
            settings.value(f"{SETTINGS_PREFIX}/max_features", 0, type=int)
        )
