"""Giao diện người dùng của plugin."""
