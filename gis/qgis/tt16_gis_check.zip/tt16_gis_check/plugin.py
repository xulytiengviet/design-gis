"""Lớp plugin QGIS: đăng ký menu, thanh công cụ và mở hộp thoại kiểm tra."""

from __future__ import annotations

from pathlib import Path

from qgis.core import Qgis, QgsMessageLog
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox

try:  # Qt6 (QGIS 4) chuyển QAction sang QtGui, Qt5 (QGIS 3) vẫn để ở QtWidgets
    from qgis.PyQt.QtGui import QAction
except ImportError:  # pragma: no cover - phụ thuộc phiên bản Qt
    from qgis.PyQt.QtWidgets import QAction

from .core.rules import DEFAULT_RULES_PATH, Rules
from .gui.main_dialog import AUTHOR_CREDIT, TT16CheckDialog

# Tên plugin hiển thị trên menu/thanh công cụ; mục bên trong menu là ACTION_TITLE.
MENU_TITLE = "Kiểm tra CSDL GIS"
ACTION_TITLE = "Kiểm tra hồ sơ GIS (TT16)"
TOOLBAR_TITLE = "Kiểm tra CSDL GIS"
LOG_TAG = "Kiểm tra CSDL GIS"
SHORTCUT = "Ctrl+Alt+K"


class TT16GisCheckPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action: QAction | None = None
        self.toolbar = None
        self.dialog: TT16CheckDialog | None = None
        self.plugin_dir = Path(__file__).resolve().parent

    def initGui(self) -> None:
        icon_path = self.plugin_dir / "resources" / "icon.svg"
        self.action = QAction(QIcon(str(icon_path)), ACTION_TITLE, self.iface.mainWindow())
        self.action.setObjectName("tt16GisCheckAction")
        self.action.setToolTip(
            "Kiểm tra hồ sơ GIS theo Thông tư 16/2025/TT-BXD - Phụ lục II: "
            f"chủ đề, lớp dữ liệu, trường thuộc tính, hệ tọa độ ({SHORTCUT})"
        )
        self.action.triggered.connect(self.run)

        # Thanh công cụ riêng: thanh "Plugins" dùng chung thường bị ẩn nên người dùng không thấy icon.
        self.toolbar = self.iface.addToolBar(TOOLBAR_TITLE)
        self.toolbar.setObjectName("TT16GisCheckToolbar")
        self.toolbar.addAction(self.action)
        self.toolbar.setVisible(True)

        self.iface.addPluginToMenu(MENU_TITLE, self.action)
        try:
            self.iface.registerMainWindowAction(self.action, SHORTCUT)
        except Exception as error:  # phím tắt trùng hoặc API khác phiên bản
            QgsMessageLog.logMessage(
                f"Không đăng ký được phím tắt {SHORTCUT}: {error}. "
                "Plugin vẫn mở được từ thanh công cụ và menu Plugins.",
                LOG_TAG,
                Qgis.MessageLevel.Warning,
            )

        QgsMessageLog.logMessage(
            f"Đã nạp plugin ({AUTHOR_CREDIT}). Mở bằng: thanh công cụ '{TOOLBAR_TITLE}', "
            f"menu Plugins > {MENU_TITLE} > {ACTION_TITLE}, hoặc phím tắt {SHORTCUT}.",
            LOG_TAG,
            Qgis.MessageLevel.Info,
        )

    def unload(self) -> None:
        if self.action is not None:
            self.iface.removePluginMenu(MENU_TITLE, self.action)
            self.iface.removeToolBarIcon(self.action)
            try:
                self.iface.unregisterMainWindowAction(self.action)
            except Exception as error:  # phím tắt chưa từng đăng ký hoặc API khác phiên bản
                QgsMessageLog.logMessage(
                    f"Không thu hồi được phím tắt {SHORTCUT}: {error}",
                    LOG_TAG,
                    Qgis.MessageLevel.Warning,
                )
            self.action = None
        if self.toolbar is not None:
            self.toolbar.deleteLater()
            self.toolbar = None
        if self.dialog is not None:
            self.dialog.close()
            self.dialog = None

    def _load_rules(self) -> Rules | None:
        try:
            return Rules.load(DEFAULT_RULES_PATH)
        except Exception as error:
            QMessageBox.critical(
                self.iface.mainWindow(),
                MENU_TITLE,
                f"Không nạp được bộ quy tắc kiểm tra:\n{error}",
            )
            return None

    def run(self) -> None:
        rules = self._load_rules()
        if rules is None:
            return
        if self.dialog is None:
            self.dialog = TT16CheckDialog(self.iface, rules, self.iface.mainWindow())
        else:
            self.dialog.rules = rules
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
