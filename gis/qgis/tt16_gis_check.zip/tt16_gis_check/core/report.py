"""Xuất báo cáo kết quả kiểm tra ra HTML và CSV."""

from __future__ import annotations

import csv
import html
from pathlib import Path

from .geometry_rules import RULE_BY_CODE
from .models import CheckGroup, Report, Severity

AUTHOR_CREDIT = "Created by Hoa Le"

CSV_HEADER = [
    "Mức độ",
    "Nhóm kiểm tra",
    "Mã quy tắc",
    "Cơ sở dữ liệu",
    "Nhóm dữ liệu",
    "Lớp dữ liệu",
    "Trường",
    "FID đối tượng",
    "Nội dung",
    "Gợi ý khắc phục",
]

_SEVERITY_COLOR = {
    Severity.ERROR: "#c0392b",
    Severity.WARNING: "#c47f00",
    Severity.INFO: "#2471a3",
    Severity.OK: "#1e8449",
}


def write_csv(report: Report, path: str | Path) -> Path:
    output = Path(path)
    # utf-8-sig để Excel trên Windows đọc đúng tiếng Việt
    with open(output, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(CSV_HEADER)
        for issue in report.sorted_issues():
            writer.writerow(
                [
                    issue.severity.label,
                    issue.group.value,
                    issue.rule_code,
                    issue.database,
                    issue.dataset,
                    issue.layer,
                    issue.field_name,
                    "" if issue.feature_id < 0 else issue.feature_id,
                    issue.message,
                    issue.hint,
                ]
            )
    return output


def _inventory_rows(report: Report) -> str:
    rows: list[str] = []
    for database in report.scan.databases:
        crs_values = sorted({layer.crs_authid or "(chưa gán)" for layer in database.layers})
        datasets = sorted({layer.dataset for layer in database.layers if layer.dataset})
        rows.append(
            "<tr><td>{code}</td><td>{path}</td><td>{datasets}</td><td>{layers}</td><td>{crs}</td></tr>".format(
                code=html.escape(database.code),
                path=html.escape(database.path),
                datasets=len(datasets),
                layers=len(database.layers),
                crs=html.escape(", ".join(crs_values)),
            )
        )
    return "\n".join(rows)


def _issue_rows(report: Report) -> str:
    rows: list[str] = []
    for issue in report.sorted_issues():
        rows.append(
            "<tr class='{cls}'>"
            "<td class='sev'>{severity}</td><td>{group}</td><td>{code}</td><td>{target}</td><td>{fid}</td>"
            "<td>{message}</td><td class='hint'>{hint}</td></tr>".format(
                cls=issue.severity.value,
                severity=html.escape(issue.severity.label),
                group=html.escape(issue.group.value),
                code=html.escape(issue.rule_code),
                target=html.escape(issue.target),
                fid="" if issue.feature_id < 0 else issue.feature_id,
                message=html.escape(issue.message),
                hint=html.escape(issue.hint),
            )
        )
    return "\n".join(rows)


def _rule_summary(report: Report) -> str:
    """Tổng hợp số vi phạm theo từng mã quy tắc hình học/topology trên toàn hồ sơ."""
    counts = report.rule_counts()
    if not counts:
        return "<tr><td colspan='5'>Không phát hiện vi phạm quy tắc hình học nào.</td></tr>"
    rows: list[str] = []
    for code in sorted(counts):
        rule = RULE_BY_CODE.get(code)
        rows.append(
            f"<tr><td>{html.escape(code)}</td>"
            f"<td>{html.escape(rule.name if rule else '')}</td>"
            f"<td>{html.escape(rule.english if rule else '')}</td>"
            f"<td>{html.escape(rule.severity.label if rule else '')}</td>"
            f"<td>{counts[code]}</td></tr>"
        )
    return "\n".join(rows)


def _shape_summary(report: Report) -> str:
    """Bảng lỗi hình học theo từng lớp và từng mã quy tắc, kèm FID để tra cứu."""
    per_key: dict[tuple[str, str], dict] = {}
    for issue in report.feature_issues():
        entry = per_key.setdefault(
            (issue.layer_key, issue.rule_code),
            {"severity": issue.severity.label, "fids": [], "count": 0},
        )
        entry["count"] += 1
        if issue.feature_id >= 0:
            entry["fids"].append(issue.feature_id)
    if not per_key:
        return "<tr><td colspan='6'>Không phát hiện đối tượng nào có lỗi hình học.</td></tr>"
    rows: list[str] = []
    for (layer_key, code), entry in sorted(per_key.items()):
        fids = entry["fids"]
        shown = ", ".join(str(fid) for fid in fids[:40])
        if len(fids) > 40:
            shown += f", ... (còn {len(fids) - 40} đối tượng)"
        if not fids:
            shown = "(vị trí lỗi, không gắn FID)"
        rule = RULE_BY_CODE.get(code)
        rows.append(
            f"<tr><td>{html.escape(layer_key)}</td><td>{html.escape(code)}</td>"
            f"<td>{html.escape(rule.name if rule else '')}</td>"
            f"<td>{html.escape(entry['severity'])}</td><td>{entry['count']}</td><td>{shown}</td></tr>"
        )
    return "\n".join(rows)


def _group_summary(report: Report) -> str:
    counts: dict[str, dict[str, int]] = {}
    for issue in report.issues:
        entry = counts.setdefault(
            issue.group.value, {"error": 0, "warning": 0, "info": 0, "ok": 0}
        )
        entry[issue.severity.value] += 1
    rows = []
    for group in CheckGroup:
        entry = counts.get(group.value)
        if not entry:
            continue
        verdict = (
            "<span class='ok'>Đạt</span>"
            if entry["error"] == 0 and entry["warning"] == 0
            else "<span class='fail'>Chưa đạt</span>"
        )
        rows.append(
            f"<tr><td>{html.escape(group.value)}</td><td>{entry['error']}</td>"
            f"<td>{entry['warning']}</td><td>{entry['info']}</td><td>{entry['ok']}</td>"
            f"<td>{verdict}</td></tr>"
        )
    return "\n".join(rows)


def build_html(report: Report) -> str:
    verdict = (
        "<span class='ok'>ĐẠT - không phát hiện lỗi</span>"
        if report.is_passed
        else f"<span class='fail'>CHƯA ĐẠT - {report.count(Severity.ERROR)} lỗi</span>"
    )
    return f"""<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<title>Báo cáo kiểm tra hồ sơ GIS - TT16/2025/TT-BXD</title>
<style>
  body {{ font-family: "Segoe UI", Arial, sans-serif; font-size: 13px; color: #222; margin: 24px; }}
  h1 {{ font-size: 19px; margin-bottom: 4px; color: #0f2c52; }}
  h2 {{
    font-size: 15px; margin-top: 26px; padding: 6px 10px; border-radius: 4px;
    background: #eef2f8; border-left: 5px solid #1f6feb; color: #0f2c52;
  }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 8px; }}
  th, td {{ border: 1px solid #dde3ea; padding: 6px 8px; text-align: left; vertical-align: top; }}
  th {{ background: #e4ebf5; color: #0f2c52; }}
  .meta td:first-child {{ width: 190px; font-weight: 600; }}
  .sev {{ white-space: nowrap; font-weight: 600; }}
  tr.error {{ background: #fdecea; }}
  tr.error .sev {{ color: {_SEVERITY_COLOR[Severity.ERROR]}; }}
  tr.error td:nth-child(6) {{ font-weight: 600; }}
  tr.warning {{ background: #fff6e5; }}
  tr.warning .sev {{ color: {_SEVERITY_COLOR[Severity.WARNING]}; }}
  tr.info {{ background: #eaf2fb; }}
  tr.info .sev {{ color: {_SEVERITY_COLOR[Severity.INFO]}; }}
  tr.ok {{ background: #ecf9f0; }}
  tr.ok .sev {{ color: {_SEVERITY_COLOR[Severity.OK]}; }}
  .hint {{ color: #555; }}
  .ok {{ color: #1e8449; font-weight: 700; }}
  .fail {{ color: {_SEVERITY_COLOR[Severity.ERROR]}; font-weight: 700; }}
  .credit {{ margin-top: 28px; padding-top: 8px; border-top: 1px solid #dde3ea; color: #64748b; }}
</style>
</head>
<body>
<h1>Báo cáo kiểm tra hồ sơ GIS quy hoạch đô thị và nông thôn</h1>
<p>Áp dụng {html.escape(report.standard)} · {AUTHOR_CREDIT}</p>

<table class="meta">
  <tr><td>Nguồn kiểm tra</td><td>{html.escape(report.scan.source_label)}</td></tr>
  <tr><td>Thời điểm kiểm tra</td><td>{html.escape(report.created_at)}</td></tr>
  <tr><td>Phiên bản bộ quy tắc</td><td>{html.escape(report.rules_version)}</td></tr>
  <tr><td>Tổng hợp</td><td>{html.escape(report.summary_text())}</td></tr>
  <tr><td>Kết luận</td><td>{verdict}</td></tr>
</table>

<h2>1. Dữ liệu đã kiểm tra</h2>
<table>
  <tr><th>Cơ sở dữ liệu</th><th>Đường dẫn</th><th>Số nhóm dữ liệu</th><th>Số lớp dữ liệu</th><th>Hệ tọa độ</th></tr>
  {_inventory_rows(report)}
</table>

<h2>2. Tổng hợp theo nhóm kiểm tra</h2>
<table>
  <tr><th>Nhóm kiểm tra</th><th>Lỗi</th><th>Cảnh báo</th><th>Thông tin</th><th>Đạt</th><th>Kết luận</th></tr>
  {_group_summary(report)}
</table>

<h2>3. Tổng hợp theo quy tắc hình học, topology</h2>
<table>
  <tr><th>Mã quy tắc</th><th>Tên quy tắc</th><th>Tên tiếng Anh</th><th>Mức độ</th><th>Số vi phạm</th></tr>
  {_rule_summary(report)}
</table>

<h2>4. Lỗi hình học theo từng lớp dữ liệu</h2>
<table>
  <tr><th>Lớp dữ liệu</th><th>Mã quy tắc</th><th>Tên quy tắc</th><th>Mức độ</th><th>Số vi phạm</th><th>FID đối tượng</th></tr>
  {_shape_summary(report)}
</table>

<h2>5. Chi tiết ({len(report.issues)} nội dung)</h2>
<table>
  <tr><th>Mức độ</th><th>Nhóm kiểm tra</th><th>Mã</th><th>Đối tượng</th><th>FID</th><th>Nội dung</th><th>Gợi ý khắc phục</th></tr>
  {_issue_rows(report)}
</table>

<p class="credit">{AUTHOR_CREDIT} · Plugin QGIS TT16 GIS Check · bộ quy tắc {html.escape(report.rules_version)}</p>
</body>
</html>
"""


def write_html(report: Report, path: str | Path) -> Path:
    output = Path(path)
    output.write_text(build_html(report), encoding="utf-8")
    return output
