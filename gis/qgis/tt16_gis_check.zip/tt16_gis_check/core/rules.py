"""Đọc và tra cứu bộ quy tắc TT16 (tt16_rules.json)."""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_RULES_PATH = Path(__file__).resolve().parent.parent / "resources" / "rules" / "tt16_rules.json"


@dataclass(frozen=True)
class FieldRule:
    name: str
    alias: str
    type: str
    length: int | None
    pattern: str | None = None
    pattern_message: str | None = None
    allow_null: bool = False


@dataclass(frozen=True)
class LayerRule:
    name: str
    alias: str
    geometry: str
    ordinal: int | None
    dataset: str
    database: str


@dataclass
class DatasetRule:
    name: str
    topic: str
    layers: list[LayerRule] = field(default_factory=list)


@dataclass
class DatabaseRule:
    code: str
    name: str
    required: bool
    severity_if_missing: str
    free_structure: bool
    note: str
    datasets: list[DatasetRule] = field(default_factory=list)

    def layer_rules(self) -> list[LayerRule]:
        return [layer for dataset in self.datasets for layer in dataset.layers]

    def layer_rule(self, layer_name: str) -> LayerRule | None:
        target = layer_name.lower()
        for layer in self.layer_rules():
            if layer.name.lower() == target:
                return layer
        return None

    def dataset_rule(self, dataset_name: str) -> DatasetRule | None:
        target = dataset_name.lower()
        for dataset in self.datasets:
            if dataset.name.lower() == target:
                return dataset
        return None


class Rules:
    """Bao bọc nội dung tt16_rules.json và cung cấp các hàm tra cứu."""

    def __init__(self, data: dict):
        self._data = data
        self.standard: str = data.get("standard", "")
        self.rules_version: str = data.get("rules_version", "")
        self.source_warnings: list[str] = list(data.get("source_warnings", []))
        self.geometry_labels: dict[str, str] = data.get("geometry_labels", {})
        self.naming: dict = data.get("naming", {})
        self.package: dict = data.get("package", {})
        self.crs: dict = data.get("crs", {})
        self.required_fields: list[FieldRule] = [
            FieldRule(
                name=item["name"],
                alias=item.get("alias", ""),
                type=item.get("type", "TEXT"),
                length=item.get("length"),
                pattern=item.get("pattern"),
                pattern_message=item.get("pattern_message"),
                allow_null=bool(item.get("allow_null", False)),
            )
            for item in data.get("required_fields", [])
        ]
        self.databases: list[DatabaseRule] = [
            self._build_database(item) for item in data.get("databases", [])
        ]

    @staticmethod
    def _build_database(item: dict) -> DatabaseRule:
        database = DatabaseRule(
            code=item["code"],
            name=item.get("name", item["code"]),
            required=bool(item.get("required", True)),
            severity_if_missing=item.get("severity_if_missing", "warning"),
            free_structure=bool(item.get("free_structure", False)),
            note=item.get("note", ""),
        )
        for dataset_item in item.get("datasets", []):
            dataset = DatasetRule(name=dataset_item["name"], topic=dataset_item.get("topic", ""))
            for layer_item in dataset_item.get("layers", []):
                dataset.layers.append(
                    LayerRule(
                        name=layer_item["name"],
                        alias=layer_item.get("alias", ""),
                        geometry=layer_item.get("geometry", ""),
                        ordinal=layer_item.get("ordinal"),
                        dataset=dataset.name,
                        database=database.code,
                    )
                )
            database.datasets.append(dataset)
        return database

    @classmethod
    def load(cls, path: str | Path | None = None) -> "Rules":
        rules_path = Path(path) if path else DEFAULT_RULES_PATH
        with open(rules_path, encoding="utf-8") as handle:
            return cls(json.load(handle))

    def database_codes(self) -> list[str]:
        return [database.code for database in self.databases]

    def database(self, code: str) -> DatabaseRule | None:
        target = (code or "").lower()
        for database in self.databases:
            if database.code.lower() == target:
                return database
        return None

    def match_database_code(self, name: str) -> str | None:
        """Nhận diện mã CSDL từ tên tệp/tên nhóm lớp, ví dụ 'QuyHoach_ABC' -> 'QuyHoach'."""
        cleaned = re.sub(r"[^a-z0-9]", "", (name or "").lower())
        if not cleaned:
            return None
        candidates = sorted(self.databases, key=lambda db: -len(db.code))
        for database in candidates:
            code = database.code.lower()
            if cleaned == code or cleaned.startswith(code) or code in cleaned:
                return database.code
        return None

    def geometry_label(self, geometry: str) -> str:
        return self.geometry_labels.get(geometry, geometry or "không xác định")

    def is_valid_layer_name(self, name: str) -> bool:
        pattern = self.naming.get("layer_regex")
        return bool(pattern) and re.fullmatch(pattern, name or "") is not None

    def is_valid_dataset_name(self, name: str) -> bool:
        pattern = self.naming.get("dataset_regex")
        return bool(pattern) and re.fullmatch(pattern, name or "") is not None


def has_diacritics(text: str) -> bool:
    """True nếu chuỗi còn dấu tiếng Việt (kể cả chữ đ/Đ)."""
    if any(ch in "đĐ" for ch in text or ""):
        return True
    return any(unicodedata.combining(ch) for ch in unicodedata.normalize("NFD", text or ""))
