"""Phần lõi kiểm tra: bộ quy tắc, đọc nguồn dữ liệu, kiểm tra và xuất báo cáo."""
