"""Kiểm tra hệ tọa độ theo yêu cầu VN-2000."""

from __future__ import annotations

import re
from dataclasses import dataclass

from .models import Issue, LayerInfo, Severity, CheckGroup
from .rules import Rules

# Tham số dịch chuyển datum VN-2000 -> WGS84 (7 tham số) dùng để nhận diện hệ tự định nghĩa.
VN2000_TOWGS84_DX = -191.90441429
TOWGS84_TOLERANCE = 0.5


@dataclass
class CrsVerdict:
    ok: bool
    is_vn2000: bool
    central_meridian: float | None
    scale_factor: float | None
    detail: str


def _find_param(proj: str, key: str) -> float | None:
    match = re.search(rf"\+{key}=(-?\d+(?:\.\d+)?)", proj or "")
    return float(match.group(1)) if match else None


def _epsg_code(authid: str) -> int | None:
    match = re.fullmatch(r"EPSG:(\d+)", (authid or "").strip(), flags=re.IGNORECASE)
    return int(match.group(1)) if match else None


def _matches_datum_name(text: str, patterns: list[str]) -> bool:
    lowered = (text or "").lower()
    return any(re.search(pattern, lowered) for pattern in patterns)


def _has_vn2000_towgs84(proj: str) -> bool:
    match = re.search(r"\+towgs84=(-?\d+(?:\.\d+)?)", proj or "")
    if not match:
        return False
    return abs(float(match.group(1)) - VN2000_TOWGS84_DX) <= TOWGS84_TOLERANCE


def evaluate_crs(layer: LayerInfo, rules: Rules) -> CrsVerdict:
    """Đánh giá một hệ tọa độ: có phải VN-2000 hợp lệ hay không."""
    config = rules.crs
    allowed_epsg = set(config.get("allowed_epsg", []))
    allowed_meridians = [float(value) for value in config.get("allowed_central_meridian", [])]
    allowed_scales = [float(value) for value in config.get("allowed_scale_factor", [])]
    datum_patterns = config.get("datum_name_patterns", [])

    code = _epsg_code(layer.crs_authid)
    central_meridian = _find_param(layer.crs_proj, "lon_0")
    scale_factor = _find_param(layer.crs_proj, "k_0") or _find_param(layer.crs_proj, "k")

    named_vn2000 = _matches_datum_name(layer.crs_description, datum_patterns) or _matches_datum_name(
        layer.crs_proj, datum_patterns
    )
    is_vn2000 = code in allowed_epsg or named_vn2000 or _has_vn2000_towgs84(layer.crs_proj)

    if code in allowed_epsg:
        return CrsVerdict(True, True, central_meridian, scale_factor, "mã EPSG thuộc danh mục VN-2000")

    if not is_vn2000:
        return CrsVerdict(False, False, central_meridian, scale_factor, "không nhận diện được datum VN-2000")

    problems: list[str] = []
    if allowed_meridians:
        if central_meridian is None:
            problems.append("không đọc được kinh tuyến trục")
        elif not any(abs(central_meridian - value) < 1e-6 for value in allowed_meridians):
            problems.append(f"kinh tuyến trục {central_meridian}° không thuộc danh mục quy định")
    if allowed_scales and scale_factor is not None:
        if not any(abs(scale_factor - value) < 1e-9 for value in allowed_scales):
            problems.append(f"hệ số điều chỉnh tỷ lệ k={scale_factor} không phải 0.9999 hoặc 0.9996")

    if problems:
        return CrsVerdict(False, True, central_meridian, scale_factor, "; ".join(problems))
    return CrsVerdict(True, True, central_meridian, scale_factor, "hệ tự định nghĩa có tham số phù hợp VN-2000")


def describe_crs(layer: LayerInfo) -> str:
    if not layer.crs_authid and not layer.crs_description:
        return "(chưa gán)"
    if layer.crs_authid and layer.crs_description:
        return f"{layer.crs_description} [{layer.crs_authid}]"
    return layer.crs_authid or layer.crs_description


def check_layer_crs(layer: LayerInfo, rules: Rules) -> list[Issue]:
    """Kiểm tra hệ tọa độ của một lớp dữ liệu."""
    issues: list[Issue] = []
    base = {
        "group": CheckGroup.CRS,
        "database": layer.database,
        "dataset": layer.dataset,
        "layer": layer.name,
        "layer_id": layer.layer_id,
    }
    config = rules.crs
    message_crs = config.get("message", "")

    if not layer.crs_is_valid or not (layer.crs_authid or layer.crs_proj):
        issues.append(
            Issue(
                **base,
                severity=Severity.ERROR,
                message="Lớp dữ liệu chưa được gán hệ tọa độ hợp lệ",
                hint=f"Gán hệ tọa độ cho lớp. {message_crs}",
            )
        )
        return issues

    if config.get("require_projected", True) and layer.crs_is_geographic:
        issues.append(
            Issue(
                **base,
                severity=Severity.ERROR,
                message=(
                    f"Hệ tọa độ {describe_crs(layer)} là hệ tọa độ địa lý (kinh/vĩ độ), "
                    "không phải hệ tọa độ phẳng"
                ),
                hint=f"Chuyển sang hệ tọa độ phẳng. {message_crs}",
            )
        )
        return issues

    verdict = evaluate_crs(layer, rules)
    if verdict.ok:
        if "tự định nghĩa" in verdict.detail:
            issues.append(
                Issue(
                    **base,
                    severity=Severity.INFO,
                    message=(
                        f"Hệ tọa độ {describe_crs(layer)} là hệ tự định nghĩa nhưng tham số phù hợp "
                        f"VN-2000 (kinh tuyến trục {verdict.central_meridian}°, k={verdict.scale_factor})"
                    ),
                    hint="Nên gán đúng mã EPSG của VN-2000 để bảo đảm tính liên thông dữ liệu",
                )
            )
        return issues

    severity = Severity.ERROR if not verdict.is_vn2000 else Severity.WARNING
    issues.append(
        Issue(
            **base,
            severity=severity,
            message=f"Hệ tọa độ {describe_crs(layer)} không đúng quy định: {verdict.detail}",
            hint=f"{message_crs}. Ví dụ: EPSG:5897 (TM-3 105-00), EPSG:3405 (UTM 48N), EPSG:3406 (UTM 49N)",
        )
    )
    return issues


def check_crs_consistency(layers: list[LayerInfo], rules: Rules) -> list[Issue]:
    """Kiểm tra toàn bộ hồ sơ dùng chung một hệ tọa độ."""
    if not rules.crs.get("require_same_crs", True):
        return []
    used: dict[str, list[str]] = {}
    for layer in layers:
        if not layer.crs_is_valid:
            continue
        key = describe_crs(layer)
        used.setdefault(key, []).append(f"{layer.database}/{layer.name}")
    if len(used) <= 1:
        return []

    detail = "; ".join(
        f"{name} ({len(layers_using)} lớp)" for name, layers_using in sorted(used.items())
    )
    return [
        Issue(
            group=CheckGroup.CRS,
            severity=Severity.WARNING,
            message=f"Hồ sơ dùng {len(used)} hệ tọa độ khác nhau: {detail}",
            hint="Toàn bộ các lớp dữ liệu của hồ sơ nên dùng chung một hệ tọa độ VN-2000",
        )
    ]
