"""Bộ kiểm tra hồ sơ GIS theo Thông tư 16/2025/TT-BXD - Phụ lục II."""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field
from pathlib import Path

from .crs import check_crs_consistency, check_layer_crs, describe_crs
from .geometry_rules import (
    RULE_BY_CODE,
    GeometryRule,
    GeometryScanResult,
    default_rule_codes,
    rules_for,
)
from .models import (
    CheckGroup,
    DatabaseInfo,
    Issue,
    LayerInfo,
    Report,
    ScanResult,
    Severity,
)
from .progress import Progress
from .rules import DatabaseRule, Rules, has_diacritics

TEXT_TYPES = {"TEXT", "STRING"}
BLOCKING = (Severity.ERROR, Severity.WARNING)


@dataclass
class CheckOptions:
    """Tùy chọn bật/tắt từng nhóm kiểm tra."""

    check_package: bool = True
    check_datasets: bool = True
    check_layers: bool = True
    check_geometry: bool = True
    check_shape: bool = True
    # Mã các quy tắc hình học/topology đang bật, xem geometry_rules.GEOMETRY_RULES.
    geometry_rules: set[str] = field(default_factory=default_rule_codes)
    check_fields: bool = True
    check_values: bool = False
    check_crs: bool = True
    report_extra_layers: bool = True
    report_passed: bool = True
    # "used": chỉ báo lớp thiếu trong các nhóm chuyên đề đã có dữ liệu; "all": báo toàn bộ theo quy định.
    missing_layers_scope: str = "used"
    strict: bool = False
    # Số đối tượng đọc tối đa mỗi lớp; 0 nghĩa là kiểm tra toàn bộ lớp dữ liệu.
    max_features: int = 0
    # Số đối tượng lỗi hình học liệt kê chi tiết cho mỗi lớp (phần vượt quá chỉ báo tổng số).
    max_shape_defects: int = 200
    # Dung sai của các quy tắc hình học, theo đơn vị hệ tọa độ của lớp.
    min_line_length: float = 0.1
    min_overlap_area: float = 0.01
    min_gap_area: float = 0.01
    expected_crs_authid: str = ""
    field_length_as_error: bool = False

    @property
    def shape_enabled(self) -> bool:
        return self.check_shape and bool(self.geometry_rules)

    def reached_limit(self, scanned: int) -> bool:
        """True khi đã đọc hết số đối tượng được phép của một lớp (0 = không giới hạn)."""
        return self.max_features > 0 and scanned >= self.max_features

    @property
    def needs_features(self) -> bool:
        return self.shape_enabled or self.check_values


def _severity(option_strict: bool, default: Severity = Severity.WARNING) -> Severity:
    return Severity.ERROR if option_strict else default


def _severity_from_name(name: str) -> Severity:
    try:
        return Severity(name)
    except ValueError:
        return Severity.WARNING


def _blocked(issues: list[Issue]) -> bool:
    """True nếu trong danh sách có lỗi hoặc cảnh báo (tức nội dung kiểm tra chưa đạt)."""
    return any(issue.severity in BLOCKING for issue in issues)


class Validator:
    def __init__(self, rules: Rules, options: CheckOptions | None = None):
        self.rules = rules
        self.options = options or CheckOptions()
        self.progress: Progress | None = None

    # ------------------------------------------------------------------ chạy
    def run(self, scan: ScanResult, progress: Progress | None = None) -> Report:
        self.progress = progress
        if progress is not None:
            progress.start(scan.layer_count, "Bắt đầu kiểm tra")
        report = Report(
            scan=scan,
            standard=self.rules.standard,
            rules_version=self.rules.rules_version,
        )
        issues: list[Issue] = []

        for note in scan.notes:
            issues.append(Issue(group=CheckGroup.PACKAGE, severity=Severity.INFO, message=note))
        for error in scan.errors:
            issues.append(
                Issue(
                    group=CheckGroup.PACKAGE,
                    severity=Severity.ERROR,
                    message=error,
                    hint="Kiểm tra lại đường dẫn nguồn dữ liệu cần kiểm tra",
                )
            )
        if not scan.errors and scan.layer_count == 0:
            issues.append(
                Issue(
                    group=CheckGroup.PACKAGE,
                    severity=Severity.ERROR,
                    message="Không đọc được lớp dữ liệu nào từ nguồn đã chọn",
                    hint=(
                        "Kiểm tra lại nguồn dữ liệu: thư mục HoSoGIS phải chứa các File Geodatabase "
                        + ", ".join(f"{code}.gdb" for code in self.rules.database_codes())
                    ),
                )
            )
            report.issues = issues
            return report

        if self.options.check_package and scan.source_kind != "file":
            issues.extend(self._check_package(scan))

        for database in scan.databases:
            issues.extend(self._check_database(database))

        if self.options.check_crs:
            all_layers = [layer for database in scan.databases for layer in database.layers]
            crs_issues = check_crs_consistency(all_layers, self.rules)
            issues.extend(crs_issues)
            if not crs_issues and len(all_layers) > 1:
                used = {describe_crs(layer) for layer in all_layers if layer.crs_is_valid}
                if used:
                    issues.extend(
                        self._pass(
                            CheckGroup.CRS,
                            f"Toàn bộ {len(all_layers)} lớp dữ liệu dùng chung một hệ tọa độ: "
                            f"{next(iter(used))}",
                        )
                    )

        report.issues = issues
        return report

    # ---------------------------------------------------------- tiện ích "Đạt"
    def _pass(self, group: CheckGroup, message: str, **kwargs) -> list[Issue]:
        if not self.options.report_passed:
            return []
        return [Issue(group=group, severity=Severity.OK, message=message, **kwargs)]

    @staticmethod
    def _layer_target(layer: LayerInfo) -> dict:
        return {
            "database": layer.database,
            "dataset": layer.dataset,
            "layer": layer.name,
            "layer_id": layer.layer_id,
            "layer_uri": layer.uri,
        }

    # -------------------------------------------------- cấu trúc hồ sơ GIS
    def _check_package(self, scan: ScanResult) -> list[Issue]:
        issues: list[Issue] = []
        package = self.rules.package
        found_codes = {database.code for database in scan.databases}

        missing_databases: list[str] = []
        for database_rule in self.rules.databases:
            if database_rule.code in found_codes or not database_rule.required:
                continue
            missing_databases.append(database_rule.code)
            issues.append(
                Issue(
                    group=CheckGroup.PACKAGE,
                    severity=_severity_from_name(database_rule.severity_if_missing),
                    database=database_rule.code,
                    message=f"Thiếu {database_rule.name} ({database_rule.code}.gdb) trong hồ sơ GIS",
                    hint=(
                        f"Bổ sung File Geodatabase {database_rule.code}.gdb vào thư mục "
                        f"{package.get('gis_folder', 'HoSoGIS')}"
                    ),
                )
            )
        if not missing_databases:
            issues.extend(
                self._pass(
                    CheckGroup.PACKAGE,
                    "Có đủ 04 cơ sở dữ liệu chính: " + ", ".join(self.rules.database_codes()),
                )
            )

        if scan.source_kind == "folder":
            root = Path(scan.root_path)
            gis_folder = package.get("gis_folder", "HoSoGIS")
            root_prefix = package.get("root_prefix", "CSDL_")
            folder_issues: list[Issue] = []
            if root.name.lower() != gis_folder.lower():
                folder_issues.append(
                    Issue(
                        group=CheckGroup.PACKAGE,
                        severity=Severity.WARNING,
                        message=f"Thư mục kiểm tra '{root.name}' không đúng tên quy định '{gis_folder}'",
                        hint=f"Đổi tên thư mục chứa dữ liệu địa lý thành {gis_folder}",
                    )
                )
            parent = root.parent
            if root.name.lower() == gis_folder.lower() and parent.name and not parent.name.startswith(root_prefix):
                folder_issues.append(
                    Issue(
                        group=CheckGroup.PACKAGE,
                        severity=Severity.WARNING,
                        message=f"Thư mục gốc hồ sơ '{parent.name}' không theo mẫu {root_prefix}<Tên đồ án quy hoạch>",
                        hint=f"Đổi tên thư mục gốc thành {root_prefix}<Tên đồ án quy hoạch>",
                    )
                )
            issues.extend(folder_issues)
            if not folder_issues:
                issues.extend(
                    self._pass(
                        CheckGroup.PACKAGE,
                        f"Cấu trúc thư mục đúng quy định: {parent.name}/{root.name}",
                    )
                )

        if not scan.project_files:
            issues.append(
                Issue(
                    group=CheckGroup.PACKAGE,
                    severity=Severity.WARNING,
                    message="Thiếu tệp tin tổng hợp cơ sở dữ liệu GIS của đồ án quy hoạch",
                    hint=(
                        "Bổ sung 01 tệp trình bày tổng hợp (định dạng "
                        + ", ".join(package.get("project_extensions", []))
                        + ") đặt tên theo tên đồ án quy hoạch"
                    ),
                )
            )
        elif len(scan.project_files) > 1:
            issues.append(
                Issue(
                    group=CheckGroup.PACKAGE,
                    severity=Severity.WARNING,
                    message=(
                        f"Có {len(scan.project_files)} tệp tổng hợp: "
                        + ", ".join(Path(item).name for item in scan.project_files)
                    ),
                    hint="Quy định chỉ lưu 01 tệp tin tổng hợp duy nhất",
                )
            )
        else:
            issues.extend(
                self._pass(
                    CheckGroup.PACKAGE,
                    f"Có 01 tệp tin tổng hợp cơ sở dữ liệu GIS: {Path(scan.project_files[0]).name}",
                )
            )

        for path in scan.unmatched_files:
            issues.append(
                Issue(
                    group=CheckGroup.PACKAGE,
                    severity=Severity.WARNING,
                    message=f"Tệp dữ liệu '{Path(path).name}' không thuộc 04 cơ sở dữ liệu chính",
                    hint=(
                        "Tên tệp đóng gói phải là "
                        + ", ".join(f"{code}.gdb" for code in self.rules.database_codes())
                    ),
                )
            )
        return issues

    # ---------------------------------------------------- từng cơ sở dữ liệu
    def _check_database(self, database: DatabaseInfo) -> list[Issue]:
        issues: list[Issue] = []
        rule = self.rules.database(database.code)

        if database.read_error:
            issues.append(
                Issue(
                    group=CheckGroup.DATABASE,
                    severity=Severity.ERROR,
                    database=database.code,
                    message=database.read_error,
                    hint="Kiểm tra lại tệp đóng gói dữ liệu có mở được bằng QGIS",
                )
            )
            return issues

        if rule is None:
            issues.append(
                Issue(
                    group=CheckGroup.DATABASE,
                    severity=Severity.WARNING,
                    database=database.code,
                    message=(
                        f"Không xác định được lớp dữ liệu thuộc cơ sở dữ liệu nào "
                        f"({len(database.layers)} lớp)"
                    ),
                    hint=(
                        "Đặt tên tệp đóng gói/nhóm lớp theo "
                        + ", ".join(self.rules.database_codes())
                    ),
                )
            )
        elif not rule.free_structure:
            if self.options.check_datasets:
                issues.extend(self._check_datasets(database, rule))
            if self.options.check_layers:
                issues.extend(self._check_layer_set(database, rule))
        else:
            issues.extend(
                self._pass(
                    CheckGroup.DATABASE,
                    f"{rule.name}: đọc được {len(database.layers)} lớp dữ liệu, "
                    "không áp dụng danh mục lớp cố định theo quy định",
                    database=database.code,
                )
            )

        for layer in database.layers:
            if self.progress is not None:
                self.progress.step(f"Kiểm tra {database.code} / {layer.name}")
            issues.extend(self._check_layer(layer, rule))
        return issues

    def _check_datasets(self, database: DatabaseInfo, rule: DatabaseRule) -> list[Issue]:
        issues: list[Issue] = []
        existing_layers = {layer.name.lower() for layer in database.layers}
        declared_datasets = {
            layer.dataset.lower() for layer in database.layers if layer.dataset
        }

        present_datasets: list[str] = []
        for dataset in rule.datasets:
            expected = {layer.name.lower() for layer in dataset.layers}
            present = expected & existing_layers
            if present or dataset.name.lower() in declared_datasets:
                present_datasets.append(dataset.name)
                issues.extend(
                    self._pass(
                        CheckGroup.DATASET,
                        f"Có nhóm dữ liệu chuyên đề '{dataset.name}' ({dataset.topic})",
                        database=database.code,
                        dataset=dataset.name,
                    )
                )
                continue
            issues.append(
                Issue(
                    group=CheckGroup.DATASET,
                    severity=_severity(self.options.strict),
                    database=database.code,
                    dataset=dataset.name,
                    message=(
                        f"Thiếu toàn bộ nhóm dữ liệu chuyên đề '{dataset.name}' "
                        f"({dataset.topic}) - {len(expected)} lớp theo quy định"
                    ),
                    hint=(
                        "Bổ sung nhóm dữ liệu và các lớp: "
                        + ", ".join(layer.name for layer in dataset.layers)
                    ),
                )
            )

        for layer in database.layers:
            if not layer.dataset or layer.dataset_source == "suy luận theo quy định":
                continue
            layer_rule = rule.layer_rule(layer.name)
            if layer_rule and layer_rule.dataset.lower() != layer.dataset.lower():
                issues.append(
                    Issue(
                        group=CheckGroup.DATASET,
                        severity=Severity.ERROR,
                        database=database.code,
                        dataset=layer.dataset,
                        layer=layer.name,
                        layer_id=layer.layer_id,
                        message=(
                            f"Lớp dữ liệu nằm ở nhóm '{layer.dataset}' nhưng quy định thuộc nhóm "
                            f"'{layer_rule.dataset}'"
                        ),
                        hint=f"Chuyển lớp {layer.name} về nhóm dữ liệu {layer_rule.dataset}",
                    )
                )
            elif not layer_rule and not rule.dataset_rule(layer.dataset):
                issues.append(
                    Issue(
                        group=CheckGroup.DATASET,
                        severity=Severity.WARNING,
                        database=database.code,
                        dataset=layer.dataset,
                        layer=layer.name,
                        layer_id=layer.layer_id,
                        message=f"Nhóm dữ liệu '{layer.dataset}' không có trong quy định",
                        hint=self.rules.naming.get("dataset_message", ""),
                    )
                )
        return issues

    def _check_layer_set(self, database: DatabaseInfo, rule: DatabaseRule) -> list[Issue]:
        """Kiểm tra danh mục lớp: lớp thiếu, lớp sai tên, lớp phát sinh."""
        issues: list[Issue] = []
        existing = {layer.name.lower(): layer for layer in database.layers}
        expected_names = [layer_rule.name for layer_rule in rule.layer_rules()]
        expected_lower = {name.lower(): name for name in expected_names}

        for dataset in rule.datasets:
            dataset_present = any(
                layer_rule.name.lower() in existing for layer_rule in dataset.layers
            ) or any(
                layer.dataset.lower() == dataset.name.lower() for layer in database.layers
            )
            if self.options.missing_layers_scope == "used" and not dataset_present:
                continue
            missing = [
                layer_rule.name
                for layer_rule in dataset.layers
                if layer_rule.name.lower() not in existing
            ]
            for name in missing:
                layer_rule = next(item for item in dataset.layers if item.name == name)
                issues.append(
                    Issue(
                        group=CheckGroup.LAYER,
                        severity=_severity(self.options.strict),
                        database=database.code,
                        dataset=dataset.name,
                        layer=name,
                        message=(
                            f"Thiếu lớp dữ liệu '{name}' ({layer_rule.alias}) - "
                            f"kiểu {self.rules.geometry_label(layer_rule.geometry)}"
                        ),
                        hint=f"Bổ sung lớp {name} vào nhóm {dataset.name}",
                    )
                )
            if dataset_present and not missing:
                issues.extend(
                    self._pass(
                        CheckGroup.LAYER,
                        f"Nhóm '{dataset.name}' có đầy đủ {len(dataset.layers)} lớp dữ liệu theo quy định",
                        database=database.code,
                        dataset=dataset.name,
                    )
                )

        for layer in database.layers:
            if layer.name.lower() in expected_lower:
                expected_name = expected_lower[layer.name.lower()]
                if layer.name != expected_name:
                    issues.append(
                        Issue(
                            group=CheckGroup.LAYER,
                            severity=Severity.ERROR,
                            database=database.code,
                            dataset=layer.dataset,
                            layer=layer.name,
                            layer_id=layer.layer_id,
                            message=(
                                f"Tên lớp viết sai chữ hoa/thường so với quy định ('{expected_name}')"
                            ),
                            hint=f"Đổi tên lớp thành {expected_name}",
                        )
                    )
                else:
                    layer_rule = rule.layer_rule(layer.name)
                    issues.extend(
                        self._pass(
                            CheckGroup.LAYER,
                            f"Tên lớp đúng quy định ({layer_rule.alias})" if layer_rule else "Tên lớp đúng quy định",
                            **self._layer_target(layer),
                        )
                    )
                continue
            if self.options.report_extra_layers:
                issues.extend(self._check_unknown_layer_name(layer, expected_names, database.code))
        return issues

    def _check_unknown_layer_name(
        self, layer: LayerInfo, expected_names: list[str], database_code: str
    ) -> list[Issue]:
        issues: list[Issue] = []
        naming = self.rules.naming
        suggestion = difflib.get_close_matches(layer.name, expected_names, n=1, cutoff=0.82)

        if suggestion:
            issues.append(
                Issue(
                    group=CheckGroup.LAYER,
                    severity=Severity.ERROR,
                    database=database_code,
                    dataset=layer.dataset,
                    layer=layer.name,
                    layer_id=layer.layer_id,
                    message=f"Tên lớp '{layer.name}' không có trong quy định, gần giống '{suggestion[0]}'",
                    hint=f"Kiểm tra và đổi tên lớp thành {suggestion[0]}",
                )
            )
            return issues

        problems: list[str] = []
        if has_diacritics(layer.name):
            problems.append("còn dấu tiếng Việt")
        if not re.search(r"_(P|L|A)$", layer.name):
            problems.append("thiếu hậu tố kiểu dữ liệu _P/_L/_A")
        if not self.rules.is_valid_layer_name(layer.name) and not problems:
            problems.append("không đúng mẫu <LopDuLieu>_<KieuDuLieu>")

        if problems:
            issues.append(
                Issue(
                    group=CheckGroup.LAYER,
                    severity=Severity.ERROR,
                    database=database_code,
                    dataset=layer.dataset,
                    layer=layer.name,
                    layer_id=layer.layer_id,
                    message=f"Tên lớp '{layer.name}' sai nguyên tắc đặt tên: " + ", ".join(problems),
                    hint=naming.get("layer_message", ""),
                )
            )
        else:
            issues.append(
                Issue(
                    group=CheckGroup.LAYER,
                    severity=Severity.INFO,
                    database=database_code,
                    dataset=layer.dataset,
                    layer=layer.name,
                    layer_id=layer.layer_id,
                    message=f"Lớp dữ liệu phát sinh ngoài quy định '{layer.name}' (tên hợp lệ)",
                    hint="Được phép tạo mới theo nguyên tắc đặt tên tại Phần 1 mục 6 khoản b",
                )
            )
        return issues

    # ----------------------------------------------------- từng lớp dữ liệu
    def _check_layer(self, layer: LayerInfo, rule: DatabaseRule | None) -> list[Issue]:
        issues: list[Issue] = []
        if not layer.fields and not layer.crs_authid and not layer.uri:
            return issues

        if not layer.crs_is_valid and not layer.fields:
            issues.append(
                Issue(
                    group=CheckGroup.LAYER,
                    severity=Severity.ERROR,
                    database=layer.database,
                    layer=layer.name,
                    message="Không mở được lớp dữ liệu",
                    hint="Kiểm tra lại dữ liệu nguồn",
                )
            )
            return issues

        if self.options.check_geometry:
            issues.extend(self._check_geometry(layer, rule))
        if self.options.check_fields:
            issues.extend(self._check_fields(layer))
        if self.options.needs_features:
            issues.extend(self._check_features(layer))
        if self.options.check_crs:
            crs_issues = check_layer_crs(layer, self.rules)
            crs_issues.extend(self._check_expected_crs(layer))
            issues.extend(crs_issues)
            if not _blocked(crs_issues):
                issues.extend(
                    self._pass(
                        CheckGroup.CRS,
                        f"Hệ tọa độ {describe_crs(layer)} đúng quy định",
                        **self._layer_target(layer),
                    )
                )
        return issues

    def _check_geometry(self, layer: LayerInfo, rule: DatabaseRule | None) -> list[Issue]:
        issues: list[Issue] = []
        base = {"group": CheckGroup.GEOMETRY, **self._layer_target(layer)}
        suffix_match = re.search(r"_(P|L|A)$", layer.name, flags=re.IGNORECASE)
        suffix = suffix_match.group(1).upper() if suffix_match else ""

        if not layer.geometry:
            issues.append(
                Issue(
                    **base,
                    severity=Severity.WARNING if suffix else Severity.INFO,
                    message=f"Lớp '{layer.name}' không có dữ liệu hình học ({layer.geometry_label})",
                    hint="Lớp dữ liệu địa lý phải có kiểu hình học điểm, đường hoặc vùng",
                )
            )
            return issues

        layer_rule = rule.layer_rule(layer.name) if rule else None
        # Khi lớp có trong quy định thì so sánh trực tiếp với quy định, tránh báo trùng hai lần.
        if layer_rule is None and suffix and suffix != layer.geometry:
            issues.append(
                Issue(
                    **base,
                    severity=Severity.ERROR,
                    message=(
                        f"Hậu tố tên lớp '_{suffix}' ({self.rules.geometry_label(suffix)}) không khớp "
                        f"kiểu hình học thực tế {self.rules.geometry_label(layer.geometry)}"
                    ),
                    hint=f"Đổi hậu tố thành _{layer.geometry} hoặc sửa lại kiểu dữ liệu của lớp",
                )
            )
        if layer_rule and layer_rule.geometry != layer.geometry:
            issues.append(
                Issue(
                    **base,
                    severity=Severity.ERROR,
                    message=(
                        f"Kiểu dữ liệu {self.rules.geometry_label(layer.geometry)} không đúng quy định "
                        f"({self.rules.geometry_label(layer_rule.geometry)})"
                    ),
                    hint=f"Lớp {layer_rule.name} phải là kiểu {self.rules.geometry_label(layer_rule.geometry)}",
                )
            )

        if not issues and (suffix or layer_rule):
            detail = "đúng quy định" if layer_rule else f"đúng với hậu tố _{suffix}"
            issues.extend(
                self._pass(
                    CheckGroup.GEOMETRY,
                    f"Kiểu dữ liệu {self.rules.geometry_label(layer.geometry)} {detail}",
                    **self._layer_target(layer),
                )
            )
        return issues

    def _check_fields(self, layer: LayerInfo) -> list[Issue]:
        issues: list[Issue] = []
        available = layer.field_names_lower()

        for field_rule in self.rules.required_fields:
            base = {
                "group": CheckGroup.FIELD,
                **self._layer_target(layer),
                "field_name": field_rule.name,
            }
            entry = available.get(field_rule.name.lower())
            if entry is None:
                issues.append(
                    Issue(
                        **base,
                        severity=Severity.ERROR,
                        message=(
                            f"Thiếu trường thuộc tính bắt buộc '{field_rule.name}' "
                            f"({field_rule.alias})"
                        ),
                        hint=(
                            f"Thêm trường {field_rule.name} kiểu {field_rule.type}"
                            + (f", độ dài {field_rule.length}" if field_rule.length else "")
                        ),
                    )
                )
                continue

            actual_name, actual_type, actual_length = entry
            if actual_name != field_rule.name:
                issues.append(
                    Issue(
                        **base,
                        severity=Severity.WARNING,
                        message=f"Trường '{actual_name}' viết sai chữ hoa/thường so với quy định",
                        hint=f"Đổi tên trường thành {field_rule.name}",
                    )
                )
            expected_type = field_rule.type.upper()
            if expected_type in TEXT_TYPES and actual_type not in TEXT_TYPES:
                issues.append(
                    Issue(
                        **base,
                        severity=Severity.ERROR,
                        message=(
                            f"Trường '{actual_name}' có kiểu {actual_type}, quy định là "
                            f"{expected_type}"
                        ),
                        hint=f"Chuyển trường {field_rule.name} sang kiểu {expected_type}",
                    )
                )
            elif field_rule.length and actual_type in TEXT_TYPES and 0 < actual_length < field_rule.length:
                issues.append(
                    Issue(
                        **base,
                        severity=Severity.ERROR if self.options.field_length_as_error else Severity.WARNING,
                        message=(
                            f"Trường '{actual_name}' có độ dài {actual_length}, "
                            f"nhỏ hơn quy định {field_rule.length}"
                        ),
                        hint=f"Đặt độ dài trường {field_rule.name} tối thiểu {field_rule.length} ký tự",
                    )
                )

        if not _blocked(issues):
            issues.extend(
                self._pass(
                    CheckGroup.FIELD,
                    f"Có đủ {len(self.rules.required_fields)} trường thuộc tính bắt buộc: "
                    + ", ".join(rule.name for rule in self.rules.required_fields),
                    **self._layer_target(layer),
                )
            )

        required_names = {rule.name.lower() for rule in self.rules.required_fields}
        extra_fields = [name for name, _, _ in layer.fields if name.lower() not in required_names]
        if layer.fields and not extra_fields:
            issues.append(
                Issue(
                    group=CheckGroup.FIELD,
                    severity=Severity.INFO,
                    **self._layer_target(layer),
                    message="Lớp chỉ có các trường tối thiểu, chưa có trường thông số chi tiết của đối tượng",
                    hint=(
                        "Ngoài các trường tối thiểu, mỗi lớp cần có thêm trường thuộc tính "
                        "về thông số chi tiết của đối tượng"
                    ),
                )
            )
        return issues

    # ----------------------------------------- hình học và giá trị thuộc tính
    def _check_features(self, layer: LayerInfo) -> list[Issue]:
        """Đọc đối tượng của lớp để kiểm tra hình học và trạng thái null của thuộc tính."""
        vector_layer = layer.qgis_layer
        if vector_layer is None:
            return []

        shape_rules = self.shape_rules(layer)
        check_values = self.options.check_values
        if not shape_rules and not check_values:
            return []

        issues: list[Issue] = []
        scanned = -1
        if shape_rules:
            from .geometry_check import scan_layer

            scan = scan_layer(
                vector_layer, layer, shape_rules, self.options, progress=self.progress
            )
            scanned = scan.scanned
            if scanned > 0:
                issues.extend(self._shape_issues(layer, scan))

        if check_values:
            value_scanned, stats = self._scan_values(vector_layer, layer)
            scanned = max(scanned, value_scanned)
            if value_scanned > 0 and stats is not None:
                issues.extend(self._value_issues(layer, value_scanned, *stats))
            # Khi không chạy quy tắc hình học thì đây là chỗ duy nhất báo việc đọc thiếu do giới hạn.
            if not shape_rules and self.options.reached_limit(value_scanned):
                issues.append(
                    Issue(
                        group=CheckGroup.VALUE,
                        severity=Severity.INFO,
                        **self._layer_target(layer),
                        message=(
                            f"Chỉ đọc {self.options.max_features} đối tượng đầu tiên của lớp "
                            "theo giới hạn đang đặt"
                        ),
                    )
                )

        if scanned == 0:
            return [
                Issue(
                    group=CheckGroup.SHAPE,
                    severity=Severity.WARNING,
                    **self._layer_target(layer),
                    message="Lớp dữ liệu không có đối tượng nào",
                    hint="Xóa lớp rỗng khỏi cơ sở dữ liệu hoặc bổ sung dữ liệu cho lớp",
                )
            ]
        return issues

    def shape_rules(self, layer: LayerInfo) -> list[GeometryRule]:
        """Các quy tắc hình học đang bật và áp dụng được cho kiểu hình học của lớp."""
        if not self.options.shape_enabled:
            return []
        return rules_for(layer.geometry, self.options.geometry_rules)

    def _scan_values(self, vector_layer, layer: LayerInfo):
        """Đọc thuộc tính bắt buộc của lớp, chỉ để đánh giá trạng thái null của giá trị."""
        available = layer.field_names_lower()
        targets = [
            (rule, available[rule.name.lower()][0])
            for rule in self.rules.required_fields
            if rule.name.lower() in available
        ]
        if not targets:
            return 0, None

        empty_counts: dict[str, int] = {}
        empty_rows = 0
        scanned = 0
        try:
            from qgis.core import QgsFeatureRequest

            request = QgsFeatureRequest()
            request.setFlags(QgsFeatureRequest.Flag.NoGeometry)
            request.setSubsetOfAttributes([name for _, name in targets], vector_layer.fields())
            for feature in vector_layer.getFeatures(request):
                if self.options.reached_limit(scanned):
                    break
                scanned += 1
                if self.progress is not None and scanned % 5000 == 0:
                    self.progress.note(f"{layer.name}: đọc thuộc tính {scanned} đối tượng")
                filled = 0
                for rule, actual_name in targets:
                    raw = feature[actual_name]
                    text = "" if raw is None else str(raw).strip()
                    if text in ("", "NULL"):
                        if not rule.allow_null:
                            empty_counts[rule.name] = empty_counts.get(rule.name, 0) + 1
                        continue
                    filled += 1
                if filled == 0:
                    empty_rows += 1
        except Exception:  # dữ liệu không đọc được thì bỏ qua, không làm gãy phiên kiểm tra
            return scanned, None
        return scanned, (len(targets), empty_counts, empty_rows)

    def _shape_issues(self, layer: LayerInfo, scan: GeometryScanResult) -> list[Issue]:
        """Mỗi vi phạm quy tắc hình học là một phát hiện riêng, có mã luật và phóng tới được."""
        issues: list[Issue] = []
        base = {"group": CheckGroup.SHAPE, **self._layer_target(layer)}

        for defect in scan.defects:
            rule = defect.rule
            issues.append(
                Issue(
                    **base,
                    severity=rule.severity,
                    rule_code=rule.code,
                    message=defect.message(),
                    hint=rule.hint,
                    feature_id=defect.feature_id,
                    other_feature_id=defect.other_id,
                    bbox=defect.bbox,
                )
            )

        if scan.total_defects > len(scan.defects):
            issues.append(
                Issue(
                    **base,
                    severity=Severity.WARNING,
                    message=(
                        f"Còn {scan.total_defects - len(scan.defects)} vi phạm hình học chưa liệt kê "
                        f"(giới hạn {self.options.max_shape_defects} vi phạm mỗi lớp)"
                    ),
                    hint="Sửa các lỗi đã liệt kê rồi kiểm tra lại, hoặc tăng giới hạn liệt kê",
                )
            )
        if scan.note:
            issues.append(Issue(**base, severity=Severity.INFO, message=scan.note))

        applied = ", ".join(scan.applied_codes)
        if scan.total_defects:
            issues.append(
                Issue(
                    **base,
                    severity=Severity.INFO,
                    message=(
                        f"Tổng hợp hình học trên {scan.scanned} đối tượng: {scan.summary()} "
                        f"(đã áp dụng {applied})"
                    ),
                )
            )
        else:
            issues.extend(
                self._pass(
                    CheckGroup.SHAPE,
                    f"Đạt toàn bộ {len(scan.applied_codes)} quy tắc hình học ({applied}) "
                    f"trên {scan.scanned} đối tượng",
                    **self._layer_target(layer),
                )
            )

        passed_codes = [code for code in scan.applied_codes if not scan.counts.get(code)]
        if scan.total_defects and passed_codes:
            issues.extend(
                self._pass(
                    CheckGroup.SHAPE,
                    "Đạt các quy tắc: "
                    + ", ".join(f"{code} ({RULE_BY_CODE[code].name})" for code in passed_codes),
                    **self._layer_target(layer),
                )
            )
        return issues

    def _value_issues(
        self,
        layer: LayerInfo,
        scanned: int,
        checked_fields: int,
        empty_counts: dict[str, int],
        empty_rows: int,
    ) -> list[Issue]:
        issues: list[Issue] = []
        if empty_rows:
            issues.append(
                Issue(
                    group=CheckGroup.VALUE,
                    severity=Severity.ERROR,
                    **self._layer_target(layer),
                    message=f"{empty_rows}/{scanned} đối tượng để trống toàn bộ trường thuộc tính bắt buộc",
                    hint="Nhập thuộc tính cho đối tượng hoặc xóa các đối tượng không có thông tin",
                )
            )

        for rule in self.rules.required_fields:
            base = {
                "group": CheckGroup.VALUE,
                **self._layer_target(layer),
                "field_name": rule.name,
            }
            empty = empty_counts.get(rule.name, 0)
            if empty:
                issues.append(
                    Issue(
                        **base,
                        severity=Severity.ERROR,
                        message=f"{empty}/{scanned} đối tượng để trống trường bắt buộc '{rule.name}'",
                        hint=f"Nhập đầy đủ giá trị {rule.alias} cho toàn bộ đối tượng",
                    )
                )

        if not _blocked(issues):
            issues.extend(
                self._pass(
                    CheckGroup.VALUE,
                    f"{checked_fields}/{len(self.rules.required_fields)} trường bắt buộc có trong lớp "
                    f"đều đã nhập đầy đủ trên {scanned} đối tượng",
                    **self._layer_target(layer),
                )
            )
        return issues

    def _check_expected_crs(self, layer: LayerInfo) -> list[Issue]:
        expected = (self.options.expected_crs_authid or "").strip()
        if not expected or not layer.crs_is_valid:
            return []
        if layer.crs_authid.upper() == expected.upper():
            return []
        return [
            Issue(
                group=CheckGroup.CRS,
                severity=Severity.ERROR,
                **self._layer_target(layer),
                message=(
                    f"Hệ tọa độ {describe_crs(layer)} khác hệ tọa độ khai báo của hồ sơ ({expected})"
                ),
                hint=f"Chuyển lớp dữ liệu về {expected}",
            )
        ]


def validate(scan: ScanResult, rules: Rules, options: CheckOptions | None = None) -> Report:
    return Validator(rules, options).run(scan)
