"""Báo tiến trình từ phần lõi ra giao diện, không phụ thuộc Qt."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

# Hàm nhận (thông điệp, số việc đã xong, tổng số việc). Tổng bằng 0 nghĩa là chưa biết tổng.
StepCallback = Callable[[str, int, int], None]


@dataclass
class Progress:
    """Đếm tiến trình theo từng bước và gọi lại giao diện sau mỗi bước."""

    on_step: Optional[StepCallback] = None
    total: int = 0
    done: int = 0

    def start(self, total: int, message: str = "") -> None:
        """Bắt đầu một giai đoạn; total <= 0 nghĩa là chưa biết tổng (giao diện chạy vô định)."""
        self.total = max(0, int(total))
        self.done = 0
        self._emit(message)

    def step(self, message: str) -> None:
        """Xong một bước."""
        self.done += 1
        self._emit(message)

    def note(self, message: str) -> None:
        """Đổi thông điệp trong khi vẫn đang ở cùng một bước (ví dụ lớp có rất nhiều đối tượng)."""
        self._emit(message)

    def _emit(self, message: str) -> None:
        if self.on_step is not None:
            self.on_step(message, self.done, self.total)
