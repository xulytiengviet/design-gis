"""Đọc thông tin lớp dữ liệu từ File Geodatabase (.gdb) - nguồn dữ liệu duy nhất được hỗ trợ."""

from __future__ import annotations

import os
from pathlib import Path

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsProject,
    QgsProviderRegistry,
    QgsVectorLayer,
    QgsWkbTypes,
)

from .models import DatabaseInfo, LayerInfo, ScanResult
from .progress import Progress
from .rules import Rules

GDB_SUFFIX = ".gdb"

# Qgis.GeometryType có từ QGIS 3.30 (và là cách duy nhất trên bản dựng Qt6/QGIS 4);
# bản cũ hơn dùng các hằng của QgsWkbTypes.
try:
    GEOMETRY_BY_QGIS = {
        Qgis.GeometryType.Point: "P",
        Qgis.GeometryType.Line: "L",
        Qgis.GeometryType.Polygon: "A",
    }
except AttributeError:  # pragma: no cover - phụ thuộc phiên bản QGIS
    GEOMETRY_BY_QGIS = {
        QgsWkbTypes.PointGeometry: "P",
        QgsWkbTypes.LineGeometry: "L",
        QgsWkbTypes.PolygonGeometry: "A",
    }

GEOMETRY_LABELS = {"P": "Điểm", "L": "Đường", "A": "Vùng"}

# Mã kiểu QVariant/QMetaType -> nhóm kiểu dữ liệu theo quy định.
_VARIANT_TYPE_MAP = {
    1: "BOOLEAN",
    2: "INTEGER",
    3: "INTEGER",
    4: "INTEGER",
    5: "INTEGER",
    6: "REAL",
    10: "TEXT",
    12: "BLOB",
    14: "DATE",
    15: "TIME",
    16: "DATETIME",
}

UNKNOWN_DATABASE = "(không xác định)"

try:  # Qgis.LayerType có từ QGIS 3.30, bản cũ hơn dùng QgsMapLayerType
    VECTOR_LAYER_TYPE = Qgis.LayerType.Vector
except AttributeError:  # pragma: no cover - phụ thuộc phiên bản QGIS
    from qgis.core import QgsMapLayerType

    VECTOR_LAYER_TYPE = QgsMapLayerType.VectorLayer


def _variant_code(value) -> int:
    """Đưa mã kiểu dữ liệu về số nguyên; PyQt6 trả về đối tượng enum thay vì số."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return int(getattr(value, "value", 0) or 0)


def normalize_field_type(type_name: str, variant_type: int) -> str:
    """Chuẩn hóa kiểu trường của nhà cung cấp dữ liệu về TEXT/INTEGER/REAL/DATE..."""
    lowered = (type_name or "").lower()
    if any(token in lowered for token in ("char", "text", "string", "json", "uuid", "guid")):
        return "TEXT"
    if any(token in lowered for token in ("datetime", "timestamp")):
        return "DATETIME"
    if "date" in lowered:
        return "DATE"
    if "time" in lowered:
        return "TIME"
    if "bool" in lowered:
        return "BOOLEAN"
    if any(token in lowered for token in ("int", "serial")):
        return "INTEGER"
    if any(token in lowered for token in ("real", "double", "float", "numeric", "decimal", "money")):
        return "REAL"
    if any(token in lowered for token in ("blob", "binary")):
        return "BLOB"
    return _VARIANT_TYPE_MAP.get(int(variant_type), (type_name or "KHÔNG RÕ").upper())


def geometry_code(layer: QgsVectorLayer) -> str:
    try:
        return GEOMETRY_BY_QGIS.get(layer.geometryType(), "")
    except Exception:
        return ""


def _crs_fields(crs: QgsCoordinateReferenceSystem) -> dict:
    if crs is None or not crs.isValid():
        return {
            "crs_authid": crs.authid() if crs else "",
            "crs_description": crs.description() if crs else "",
            "crs_is_valid": False,
            "crs_is_geographic": False,
            "crs_proj": "",
        }
    try:
        proj = crs.toProj()
    except AttributeError:  # QGIS < 3.10
        proj = crs.toProj4()
    return {
        "crs_authid": crs.authid(),
        "crs_description": crs.description(),
        "crs_is_valid": True,
        "crs_is_geographic": crs.isGeographic(),
        "crs_proj": proj or "",
    }


def layer_info_from_vector_layer(
    layer: QgsVectorLayer,
    *,
    name: str | None = None,
    database: str = "",
    dataset: str = "",
    dataset_source: str = "suy luận",
    count_features: bool = False,
) -> LayerInfo:
    """Chuyển một QgsVectorLayer thành LayerInfo."""
    fields: list[tuple[str, str, int]] = []
    for field in layer.fields():
        fields.append(
            (
                field.name(),
                normalize_field_type(field.typeName(), _variant_code(field.type())),
                _variant_code(field.length()),
            )
        )
    geometry = geometry_code(layer)
    info = LayerInfo(
        name=name or layer.name(),
        database=database,
        dataset=dataset,
        dataset_source=dataset_source,
        geometry=geometry,
        geometry_label=GEOMETRY_LABELS.get(geometry, "Hình học khác")
        if layer.isSpatial()
        else "Bảng phi không gian",
        fields=fields,
        feature_count=layer.featureCount() if count_features else -1,
        uri=layer.source(),
        layer_id=layer.id() if layer.id() else "",
        qgis_layer=layer,
        **_crs_fields(layer.crs()),
    )
    return info


def _sublayer_uris(container: Path) -> list[tuple[str, str]]:
    """Trả về danh sách (tên lớp, uri) trong một tệp đóng gói dữ liệu."""
    registry = QgsProviderRegistry.instance()
    results: list[tuple[str, str]] = []
    try:
        flags = Qgis.SublayerQueryFlag.ResolveGeometryType
        for details in registry.querySublayers(str(container), flags):
            if details.type() != VECTOR_LAYER_TYPE:
                continue
            results.append((details.name(), details.uri()))
    except Exception:
        probe = QgsVectorLayer(str(container), "probe", "ogr")
        for entry in probe.dataProvider().subLayers():
            parts = entry.split("!!::!!")
            if len(parts) >= 2:
                name = parts[1]
                results.append((name, f"{container}|layername={name}"))

    unique: dict[str, str] = {}
    for name, uri in results:
        unique.setdefault(name, uri)
    return list(unique.items())


def _filegdb_datasets(container: Path) -> dict[str, str]:
    """Đọc quan hệ lớp -> nhóm dữ liệu (feature dataset) trong File Geodatabase."""
    mapping: dict[str, str] = {}
    try:
        from osgeo import gdal

        gdal.UseExceptions()
        dataset = gdal.OpenEx(
            str(container), gdal.OF_VECTOR | gdal.OF_READONLY, open_options=["LIST_ALL_TABLES=YES"]
        )
        if dataset is None:
            return mapping
        items = dataset.GetLayerByName("GDB_Items")
        if items is None:
            return mapping
        items.ResetReading()
        for feature in items:
            item_path = feature.GetField("Path") if feature.GetFieldIndex("Path") >= 0 else None
            if not item_path:
                continue
            parts = [part for part in str(item_path).replace("/", "\\").split("\\") if part]
            if len(parts) >= 2:
                mapping[parts[-1].lower()] = parts[-2]
    except Exception:
        return mapping
    return mapping


def _split_dataset_prefix(layer_name: str, rules: Rules, database_code: str) -> tuple[str, str]:
    """Tách tiền tố nhóm dữ liệu khỏi tên lớp nếu có, ví dụ 'ViTriRanhGioi.RanhGioiQuyHoach_A'."""
    database = rules.database(database_code)
    if not database:
        return layer_name, ""
    for separator in (".", "/", "\\"):
        if separator in layer_name:
            head, tail = layer_name.rsplit(separator, 1)
            if database.dataset_rule(head.split(separator)[-1]):
                return tail, head.split(separator)[-1]
    for dataset in database.datasets:
        prefix = f"{dataset.name}_".lower()
        if layer_name.lower().startswith(prefix) and database.layer_rule(layer_name[len(prefix) :]):
            return layer_name[len(prefix) :], dataset.name
    return layer_name, ""


def resolve_dataset(layer: LayerInfo, rules: Rules) -> None:
    """Xác định nhóm dữ liệu của lớp: ưu tiên thông tin đọc được, sau đó suy luận từ quy định."""
    if layer.dataset:
        return
    database = rules.database(layer.database)
    if not database:
        return
    rule = database.layer_rule(layer.name)
    if rule:
        layer.dataset = rule.dataset
        layer.dataset_source = "suy luận theo quy định"


def enumerate_container(
    container: Path,
    database_code: str,
    rules: Rules,
    count_features: bool = False,
    progress: Progress | None = None,
) -> DatabaseInfo:
    """Đọc toàn bộ lớp dữ liệu trong một File Geodatabase."""
    database = DatabaseInfo(code=database_code, path=str(container))
    if progress is not None:
        progress.note(f"Đang mở {container.name}")
    gdb_datasets = _filegdb_datasets(container)
    entries = _sublayer_uris(container)

    if not entries:
        database.read_error = "Không đọc được lớp dữ liệu nào trong File Geodatabase này"
        return database

    for position, (raw_name, uri) in enumerate(sorted(entries), start=1):
        if progress is not None:
            progress.note(f"Đọc {container.name}: {raw_name} ({position}/{len(entries)})")
        vector_layer = QgsVectorLayer(uri, raw_name, "ogr")
        if not vector_layer.isValid():
            database.layers.append(
                LayerInfo(name=raw_name, database=database_code, uri=uri)
            )
            continue
        clean_name, dataset_from_name = _split_dataset_prefix(raw_name, rules, database_code)
        dataset = gdb_datasets.get(raw_name.lower(), "") or dataset_from_name
        info = layer_info_from_vector_layer(
            vector_layer,
            name=clean_name,
            database=database_code,
            dataset=dataset,
            dataset_source="đọc từ feature dataset" if dataset else "suy luận",
            count_features=count_features,
        )
        resolve_dataset(info, rules)
        database.layers.append(info)
    return database


def _container_candidates(folder: Path) -> tuple[list[Path], list[Path]]:
    """Trả về (các .gdb, các tệp đóng gói định dạng khác bị bỏ qua)."""
    gdb: list[Path] = []
    others: list[Path] = []
    other_extensions = {".gpkg", ".sqlite", ".geopackage", ".shp", ".mdb", ".tab", ".kml", ".dwg", ".dxf"}
    for entry in sorted(folder.iterdir()):
        if entry.is_dir() and entry.suffix.lower() == GDB_SUFFIX:
            gdb.append(entry)
        elif entry.is_file() and entry.suffix.lower() in other_extensions:
            others.append(entry)
    return gdb, others


def scan_folder(
    folder: str | Path,
    rules: Rules,
    count_features: bool = False,
    progress: Progress | None = None,
) -> ScanResult:
    """Quét một thư mục HoSoGIS, chỉ đọc các File Geodatabase (.gdb) bên trong."""
    root = Path(folder)
    result = ScanResult(
        source_label=f"Thư mục: {root}", source_kind="folder", root_path=str(root)
    )
    if not root.is_dir():
        result.errors.append(f"Không tìm thấy thư mục {root}")
        return result

    gis_folder = rules.package.get("gis_folder", "HoSoGIS")
    if root.name.lower() != gis_folder.lower():
        nested = next(
            (child for child in root.iterdir() if child.is_dir() and child.name.lower() == gis_folder.lower()),
            None,
        )
        if nested is not None:
            result.notes.append(f"Đã tự chuyển vào thư mục con {gis_folder}")
            root = nested
            result.root_path = str(root)
            result.source_label = f"Thư mục: {root}"

    project_extensions = {ext.lower() for ext in rules.package.get("project_extensions", [])}
    for entry in sorted(root.iterdir()):
        if entry.is_file() and entry.suffix.lower() in project_extensions:
            result.project_files.append(str(entry))

    gdb_containers, ignored = _container_candidates(root)
    for path in ignored:
        result.notes.append(
            f"Bỏ qua '{path.name}': plugin chỉ đọc dữ liệu từ File Geodatabase (.gdb)"
        )
    if not gdb_containers:
        result.errors.append(
            f"Thư mục {root} không có File Geodatabase nào. Cần các thư mục "
            + ", ".join(f"{code}.gdb" for code in rules.database_codes())
        )
        return result

    for container in gdb_containers:
        code = rules.match_database_code(container.stem)
        if code is None:
            result.unmatched_files.append(str(container))
            continue
        result.databases.append(
            enumerate_container(
                container, code, rules, count_features=count_features, progress=progress
            )
        )
    return result


def scan_file(
    path: str | Path,
    rules: Rules,
    count_features: bool = False,
    progress: Progress | None = None,
) -> ScanResult:
    """Quét một File Geodatabase duy nhất."""
    container = Path(path)
    result = ScanResult(
        source_label=f"File Geodatabase: {container}",
        source_kind="file",
        root_path=str(container.parent),
    )
    if not container.exists():
        result.errors.append(f"Không tìm thấy {container}")
        return result
    if container.suffix.lower() != GDB_SUFFIX:
        result.errors.append(
            f"'{container.name}' không phải File Geodatabase. Plugin chỉ đọc dữ liệu từ thư mục *.gdb"
        )
        return result
    code = rules.match_database_code(container.stem)
    if code is None:
        code = UNKNOWN_DATABASE
        result.notes.append(
            f"Tên '{container.name}' không khớp mã CSDL nào "
            f"({', '.join(rules.database_codes())}), chỉ kiểm tra được lớp/trường/hình học/hệ tọa độ"
        )
    result.databases.append(
        enumerate_container(
            container, code, rules, count_features=count_features, progress=progress
        )
    )
    return result


def scan(
    source_kind: str,
    target: str,
    rules: Rules,
    count_features: bool = False,
    progress: Progress | None = None,
) -> ScanResult:
    """Điểm vào chung: chọn cách quét theo loại nguồn (.gdb đơn lẻ hoặc thư mục chứa .gdb)."""
    if progress is not None:
        # Chưa biết tổng số lớp trước khi mở dữ liệu nên giai đoạn này chạy vô định.
        progress.start(0, "Đang đọc nguồn dữ liệu")
    if source_kind == "folder":
        return scan_folder(target, rules, count_features=count_features, progress=progress)
    if source_kind == "file":
        return scan_file(target, rules, count_features=count_features, progress=progress)
    raise ValueError(
        f"Loại nguồn không hợp lệ: {source_kind}. Chỉ hỗ trợ 'folder' (thư mục chứa .gdb) "
        "hoặc 'file' (một .gdb)"
    )


def guess_hosogis_folder(project: QgsProject) -> str:
    """Đoán thư mục HoSoGIS từ project đang mở, phục vụ điền sẵn ô chọn đường dẫn."""
    if not project.fileName():
        return ""
    current = Path(project.fileName()).parent
    for candidate in [current, *current.parents][:4]:
        if candidate.name.lower() == "hosogis":
            return str(candidate)
        nested = candidate / "HoSoGIS"
        if nested.is_dir():
            return str(nested)
    return str(current) if os.path.isdir(current) else ""
