"""Danh mục quy tắc kiểm tra hình học và topology (mã G/P/L/A).

Phần này không phụ thuộc QGIS: chỉ khai báo quy tắc và kết quả kiểm tra.
Phần đánh giá hình học thật nằm ở `geometry_check.py`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .models import Severity

# Kiểu hình học áp dụng: P (điểm), L (đường), A (vùng); rỗng = mọi kiểu.
ALL_GEOMETRIES: tuple[str, ...] = ()


@dataclass(frozen=True)
class GeometryRule:
    code: str
    name: str
    english: str
    problem: str  # mô tả vi phạm, dùng trong thông báo lỗi
    severity: Severity
    hint: str
    geometries: tuple[str, ...] = ALL_GEOMETRIES
    default_enabled: bool = True
    # Cần so sánh giữa các đối tượng trong cùng lớp.
    pairwise: bool = False
    # Cần gộp toàn bộ đối tượng của lớp mới kết luận được.
    layerwide: bool = False

    @property
    def label(self) -> str:
        return f"{self.code} - {self.name} ({self.english})"

    def applies_to(self, geometry_code: str) -> bool:
        if not geometry_code:
            return False
        return not self.geometries or geometry_code in self.geometries


GEOMETRY_RULES: tuple[GeometryRule, ...] = (
    GeometryRule(
        code="A01",
        name="Vùng chồng đè",
        english="Overlap",
        problem="chồng đè lên vùng khác",
        severity=Severity.ERROR,
        hint="Dùng công cụ chỉnh sửa nút/cạnh hoặc Vector > Geoprocessing để cắt bỏ phần chồng đè",
        geometries=("A",),
        pairwise=True,
    ),
    GeometryRule(
        code="A02",
        name="Vùng trùng lặp",
        english="Duplicate polygons",
        problem="trùng hoàn toàn với vùng khác",
        severity=Severity.ERROR,
        hint="Xóa vùng bị nhân bản, giữ lại một đối tượng duy nhất",
        geometries=("A",),
        pairwise=True,
    ),
    GeometryRule(
        code="A03",
        name="Khe hở giữa các vùng",
        english="Gap",
        problem="khe hở giữa các vùng",
        severity=Severity.WARNING,
        hint="Bắt điểm (snapping) và dùng Fill Gaps / chỉnh cạnh để khép kín giữa các vùng liền kề",
        geometries=("A",),
        default_enabled=False,
        layerwide=True,
    ),
    GeometryRule(
        code="G00",
        name="Hình học hợp lệ",
        english="Is Valid",
        problem="hình học không hợp lệ",
        severity=Severity.ERROR,
        hint="Dùng Vector > Geometry Tools > Check Validity / Fix Geometries để sửa",
    ),
    GeometryRule(
        code="G01",
        name="Trùng lặp đối tượng",
        english="Duplicate features",
        problem="trùng lặp hoàn toàn với đối tượng khác (cả hình học và thuộc tính)",
        severity=Severity.ERROR,
        hint="Xóa các đối tượng bị nhân bản do chồng lớp hoặc copy/paste nhiều lần",
        pairwise=True,
    ),
    GeometryRule(
        code="G02",
        name="Hình học rỗng/null",
        english="Null/Empty geometry",
        problem="không có hình học (null/rỗng)",
        severity=Severity.ERROR,
        hint="Xóa đối tượng không có hình học hoặc vẽ lại hình học cho đối tượng",
    ),
    GeometryRule(
        code="G03",
        name="Sai hệ tọa độ tham chiếu với hình học",
        english="CRS mismatch",
        problem="tọa độ không nằm trong phạm vi hệ tọa độ khai báo của lớp",
        severity=Severity.ERROR,
        hint=(
            "Kiểm tra lại hệ tọa độ của lớp: dữ liệu độ/phút/giây gán vào hệ chiếu mét "
            "(hoặc ngược lại) phải được chuyển đổi bằng Export > Save Features As"
        ),
    ),
    GeometryRule(
        code="L02",
        name="Đường trùng lặp",
        english="Duplicate lines",
        problem="trùng hoàn toàn với đường khác",
        severity=Severity.ERROR,
        hint="Xóa đường bị nhân bản, giữ lại một đối tượng duy nhất",
        geometries=("L",),
        pairwise=True,
    ),
    GeometryRule(
        code="L04",
        name="Đường quá ngắn / độ dài bằng 0",
        english="Zero-length / sliver line",
        problem="đường quá ngắn hoặc có độ dài bằng 0",
        severity=Severity.WARNING,
        hint="Xóa đoạn vụn, hoặc gộp vào đường liền kề bằng công cụ chỉnh sửa nút",
        geometries=("L",),
    ),
    GeometryRule(
        code="P01",
        name="Điểm trùng lặp",
        english="Duplicate points",
        problem="trùng vị trí với điểm khác",
        severity=Severity.ERROR,
        hint="Xóa điểm bị nhân bản, hoặc tách vị trí nếu là hai đối tượng khác nhau",
        geometries=("P",),
        pairwise=True,
    ),
)

RULE_BY_CODE: dict[str, GeometryRule] = {rule.code: rule for rule in GEOMETRY_RULES}
DEFAULT_RULE_CODES: frozenset[str] = frozenset(
    rule.code for rule in GEOMETRY_RULES if rule.default_enabled
)
ALL_RULE_CODES: frozenset[str] = frozenset(RULE_BY_CODE)

# Quy tắc trùng lặp theo kiểu hình học, dùng khi hai đối tượng giống nhau về hình học.
DUPLICATE_CODE_BY_GEOMETRY = {"P": "P01", "L": "L02", "A": "A02"}


def default_rule_codes() -> set[str]:
    return set(DEFAULT_RULE_CODES)


def parse_rule_codes(value: str) -> set[str]:
    """Đọc danh sách mã quy tắc từ chuỗi: 'all', 'none' hoặc 'G00,A01,...'."""
    text = (value or "").strip().lower()
    if not text or text == "default":
        return default_rule_codes()
    if text == "all":
        return set(ALL_RULE_CODES)
    if text == "none":
        return set()
    codes: set[str] = set()
    unknown: list[str] = []
    for part in value.replace(";", ",").split(","):
        code = part.strip().upper()
        if not code:
            continue
        if code in RULE_BY_CODE:
            codes.add(code)
        else:
            unknown.append(code)
    if unknown:
        raise ValueError(
            "Mã quy tắc không hợp lệ: "
            + ", ".join(unknown)
            + ". Các mã hợp lệ: "
            + ", ".join(sorted(ALL_RULE_CODES))
        )
    return codes


def rules_for(geometry_code: str, enabled_codes) -> list[GeometryRule]:
    """Các quy tắc đang bật và áp dụng được cho kiểu hình học của lớp."""
    codes = set(enabled_codes or ())
    return [rule for rule in GEOMETRY_RULES if rule.code in codes and rule.applies_to(geometry_code)]


@dataclass
class ShapeDefect:
    """Một vi phạm quy tắc hình học, kèm thông tin để phóng tới trên bản đồ."""

    code: str
    feature_id: int = -1
    other_id: int = -1
    detail: str = ""
    bbox: tuple[float, float, float, float] | None = None

    @property
    def rule(self) -> GeometryRule:
        return RULE_BY_CODE[self.code]

    def message(self) -> str:
        rule = self.rule
        if self.feature_id < 0:
            head = f"[{rule.code}] {rule.name}"
        else:
            head = f"[{rule.code}] Đối tượng FID {self.feature_id}: {rule.problem}"
            if self.other_id >= 0:
                head = f"{head} (FID {self.other_id})"
        return f"{head} - {self.detail}" if self.detail else head


@dataclass
class GeometryScanResult:
    """Kết quả chạy các quy tắc hình học trên một lớp."""

    scanned: int = 0
    applied_codes: list[str] = field(default_factory=list)
    defects: list[ShapeDefect] = field(default_factory=list)
    counts: dict[str, int] = field(default_factory=dict)
    note: str = ""

    @property
    def total_defects(self) -> int:
        return sum(self.counts.values())

    def summary(self) -> str:
        parts = [
            f"{count} lỗi {RULE_BY_CODE[code].code}" for code, count in sorted(self.counts.items()) if count
        ]
        return ", ".join(parts)
