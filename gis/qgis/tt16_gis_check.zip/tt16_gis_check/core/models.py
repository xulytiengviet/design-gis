"""Các kiểu dữ liệu dùng chung cho kết quả kiểm tra."""

from __future__ import annotations

import datetime as _datetime
from dataclasses import dataclass, field
from enum import Enum


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    # Mức "đạt" dùng mã "ok": trình quét bảo mật của kho plugin QGIS coi mọi tên/khóa
    # chứa chữ "pass" là mật khẩu ghi cứng nên tránh dùng chữ đó trong mã nguồn.
    OK = "ok"

    @property
    def label(self) -> str:
        return {"error": "Lỗi", "warning": "Cảnh báo", "info": "Thông tin", "ok": "Đạt"}[self.value]

    @property
    def rank(self) -> int:
        return {"error": 0, "warning": 1, "info": 2, "ok": 3}[self.value]


class CheckGroup(str, Enum):
    PACKAGE = "Cấu trúc hồ sơ"
    DATABASE = "Cơ sở dữ liệu"
    DATASET = "Nhóm dữ liệu (chủ đề)"
    LAYER = "Lớp dữ liệu"
    GEOMETRY = "Kiểu dữ liệu hình học"
    SHAPE = "Hình học, topology"
    FIELD = "Trường thuộc tính"
    VALUE = "Giá trị thuộc tính"
    CRS = "Hệ tọa độ"


@dataclass
class Issue:
    """Một phát hiện không phù hợp quy định."""

    group: CheckGroup
    severity: Severity
    message: str
    database: str = ""
    dataset: str = ""
    layer: str = ""
    field_name: str = ""
    hint: str = ""
    layer_id: str = ""
    # Mã quy tắc hình học/topology (G00, A01...) nếu phát hiện gắn với một quy tắc cụ thể.
    rule_code: str = ""
    # Thông tin định vị đối tượng lỗi trên bản đồ.
    layer_uri: str = ""
    feature_id: int = -1
    # Đối tượng thứ hai của cặp vi phạm (trùng lặp, chồng đè).
    other_feature_id: int = -1
    bbox: tuple[float, float, float, float] | None = None

    @property
    def target(self) -> str:
        parts = [part for part in (self.database, self.dataset, self.layer, self.field_name) if part]
        return " / ".join(parts) if parts else "(hồ sơ)"

    @property
    def layer_key(self) -> str:
        return " / ".join(part for part in (self.database, self.dataset, self.layer) if part)

    @property
    def is_feature_issue(self) -> bool:
        """Phát hiện gắn với một vị trí cụ thể: một đối tượng (FID) hoặc một vùng lỗi (khe hở)."""
        return self.feature_id >= 0 or self.bbox is not None

    @property
    def can_locate(self) -> bool:
        """Có thể chọn/phóng tới vị trí lỗi này trên bản đồ hay không."""
        if not (self.layer_uri or self.layer_id):
            return False
        return self.feature_id >= 0 or self.bbox is not None

    def as_row(self) -> list[str]:
        return [
            self.severity.label,
            self.group.value,
            self.rule_code,
            self.target,
            "" if self.feature_id < 0 else str(self.feature_id),
            self.message,
            self.hint,
        ]


@dataclass
class LayerInfo:
    """Thông tin một lớp dữ liệu đã đọc được từ nguồn."""

    name: str
    database: str = ""
    dataset: str = ""
    dataset_source: str = "suy luận"
    geometry: str = ""  # P / L / A / "" (không gian hình học khác hoặc bảng)
    geometry_label: str = ""
    crs_authid: str = ""
    crs_description: str = ""
    crs_is_valid: bool = False
    crs_is_geographic: bool = False
    crs_proj: str = ""
    fields: list[tuple[str, str, int]] = field(default_factory=list)  # (tên, kiểu, độ dài)
    feature_count: int = -1
    uri: str = ""
    layer_id: str = ""
    # Tham chiếu tới QgsVectorLayer (nếu có) để đọc giá trị thuộc tính khi cần.
    qgis_layer: object | None = field(default=None, repr=False, compare=False)

    def field_names_lower(self) -> dict[str, tuple[str, str, int]]:
        return {name.lower(): (name, type_name, length) for name, type_name, length in self.fields}


@dataclass
class DatabaseInfo:
    """Một cơ sở dữ liệu chính (HienTrang/QuyHoach/NenDiaHinh/MocGioi) đã tìm thấy."""

    code: str
    path: str = ""
    layers: list[LayerInfo] = field(default_factory=list)
    read_error: str = ""


@dataclass
class ScanResult:
    """Toàn bộ dữ liệu đọc được từ nguồn kiểm tra."""

    source_label: str = ""
    source_kind: str = ""  # "project" | "folder" | "file"
    root_path: str = ""
    databases: list[DatabaseInfo] = field(default_factory=list)
    project_files: list[str] = field(default_factory=list)
    unmatched_files: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def database(self, code: str) -> DatabaseInfo | None:
        for database in self.databases:
            if database.code == code:
                return database
        return None

    @property
    def layer_count(self) -> int:
        return sum(len(database.layers) for database in self.databases)


@dataclass
class Report:
    """Kết quả kiểm tra hoàn chỉnh."""

    scan: ScanResult
    issues: list[Issue] = field(default_factory=list)
    standard: str = ""
    rules_version: str = ""
    created_at: str = field(
        default_factory=lambda: _datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    )

    def count(self, severity: Severity) -> int:
        return sum(1 for issue in self.issues if issue.severity is severity)

    @property
    def is_passed(self) -> bool:
        return self.count(Severity.ERROR) == 0

    def sorted_issues(self) -> list[Issue]:
        return sorted(
            self.issues,
            key=lambda issue: (
                issue.severity.rank,
                issue.database,
                issue.dataset,
                issue.layer,
                issue.field_name,
                issue.rule_code,
                issue.feature_id,
            ),
        )

    def rule_counts(self) -> dict[str, int]:
        """Số vi phạm theo từng mã quy tắc hình học."""
        counts: dict[str, int] = {}
        for issue in self.issues:
            if issue.rule_code:
                counts[issue.rule_code] = counts.get(issue.rule_code, 0) + 1
        return counts

    def feature_issues(self, layer_key: str = "") -> list[Issue]:
        """Các phát hiện gắn với một đối tượng cụ thể, phục vụ phóng tới lỗi trên bản đồ."""
        return [
            issue
            for issue in self.sorted_issues()
            if issue.is_feature_issue and (not layer_key or issue.layer_key == layer_key)
        ]

    def summary_text(self) -> str:
        return (
            f"{self.count(Severity.ERROR)} lỗi, "
            f"{self.count(Severity.WARNING)} cảnh báo, "
            f"{self.count(Severity.INFO)} thông tin, "
            f"{self.count(Severity.OK)} nội dung đạt "
            f"trên {self.scan.layer_count} lớp dữ liệu"
        )
