"""Đánh giá các quy tắc hình học/topology trên một lớp dữ liệu (cần QGIS)."""

from __future__ import annotations

from qgis.core import (
    Qgis,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMessageLog,
    QgsProject,
    QgsRectangle,
    QgsSpatialIndex,
)

from .geometry_rules import (
    DUPLICATE_CODE_BY_GEOMETRY,
    GeometryRule,
    GeometryScanResult,
    ShapeDefect,
)
from .models import LayerInfo

LOG_TAG = "Kiểm tra CSDL GIS"
WARNING_LEVEL = Qgis.MessageLevel.Warning

# Nới phạm vi hệ tọa độ khi kiểm tra G03 để không báo sai ở vùng rìa (đơn vị của hệ tọa độ).
CRS_BOUNDS_MARGIN_PROJECTED = 1000.0
CRS_BOUNDS_MARGIN_GEOGRAPHIC = 0.5

# Các trường do định dạng lưu trữ tự sinh, không dùng để so sánh trùng lặp đối tượng (G01).
INTERNAL_FIELDS = {
    "objectid",
    "fid",
    "oid",
    "globalid",
    "shape_length",
    "shape_leng",
    "shape_area",
    "st_length(shape)",
    "st_area(shape)",
}


def _bbox(geometry: QgsGeometry) -> tuple[float, float, float, float]:
    box = geometry.boundingBox()
    return (box.xMinimum(), box.yMinimum(), box.xMaximum(), box.yMaximum())


def crs_extent(crs: QgsCoordinateReferenceSystem) -> QgsRectangle | None:
    """Phạm vi sử dụng của hệ tọa độ, chuyển về đúng đơn vị của hệ tọa độ đó."""
    if crs is None or not crs.isValid():
        return None
    bounds = crs.bounds()  # luôn ở đơn vị độ (WGS84)
    if bounds is None or bounds.isNull() or bounds.isEmpty():
        return None
    if crs.isGeographic():
        extent = QgsRectangle(bounds)
        extent.grow(CRS_BOUNDS_MARGIN_GEOGRAPHIC)
        return extent
    try:
        transform = QgsCoordinateTransform(
            QgsCoordinateReferenceSystem("EPSG:4326"), crs, QgsProject.instance()
        )
        extent = transform.transformBoundingBox(bounds)
    except Exception:
        return None
    if extent.isNull() or extent.isEmpty():
        return None
    extent.grow(CRS_BOUNDS_MARGIN_PROJECTED)
    return extent


def comparable_field_indexes(vector_layer) -> list[int]:
    """Chỉ số các trường dùng để so sánh hai đối tượng có trùng lặp hoàn toàn hay không."""
    return [
        index
        for index, field in enumerate(vector_layer.fields())
        if field.name().lower() not in INTERNAL_FIELDS
    ]


def _describe_extent(extent: QgsRectangle) -> str:
    return (
        f"phạm vi hợp lệ X {extent.xMinimum():.0f}..{extent.xMaximum():.0f}, "
        f"Y {extent.yMinimum():.0f}..{extent.yMaximum():.0f}"
    )


class _DefectCollector:
    """Giữ toàn bộ số lượng vi phạm nhưng chỉ liệt kê chi tiết trong giới hạn cho phép."""

    def __init__(self, limit: int):
        self.limit = max(int(limit), 0)
        self.defects: list[ShapeDefect] = []
        self.counts: dict[str, int] = {}

    def add(self, code: str, **kwargs) -> None:
        self.counts[code] = self.counts.get(code, 0) + 1
        if len(self.defects) < self.limit:
            self.defects.append(ShapeDefect(code, **kwargs))


def scan_layer(
    vector_layer,
    layer: LayerInfo,
    rules: list[GeometryRule],
    options,
    progress=None,
) -> GeometryScanResult:
    """Chạy các quy tắc hình học đang bật trên một lớp, trả về danh sách vi phạm theo đối tượng."""
    result = GeometryScanResult(applied_codes=[rule.code for rule in rules])
    if vector_layer is None or not rules:
        return result

    codes = {rule.code for rule in rules}
    duplicate_code = DUPLICATE_CODE_BY_GEOMETRY.get(layer.geometry, "")
    needs_geometry_cache = any(rule.pairwise or rule.layerwide for rule in rules)
    needs_attributes = "G01" in codes
    collector = _DefectCollector(options.max_shape_defects)

    extent = crs_extent(vector_layer.crs()) if "G03" in codes else None
    compared_fields = comparable_field_indexes(vector_layer) if needs_attributes else []
    geometries: dict[int, QgsGeometry] = {}
    attribute_keys: dict[int, tuple] = {}
    index = QgsSpatialIndex() if needs_geometry_cache else None

    request = QgsFeatureRequest()
    if not needs_attributes:
        request.setNoAttributes()

    try:
        for feature in vector_layer.getFeatures(request):
            if options.reached_limit(result.scanned):
                result.note = (
                    f"Chỉ kiểm tra {options.max_features} đối tượng đầu tiên của lớp "
                    "theo giới hạn đang đặt"
                )
                break
            result.scanned += 1
            if progress is not None and result.scanned % 2000 == 0:
                progress.note(f"{layer.name}: đọc hình học {result.scanned} đối tượng")
            geometry = feature.geometry()
            if geometry is None or geometry.isNull() or geometry.isEmpty():
                if "G02" in codes:
                    collector.add("G02", feature_id=feature.id())
                continue

            box = _bbox(geometry)
            if "G00" in codes and not geometry.isGeosValid():
                errors = geometry.validateGeometry()
                collector.add(
                    "G00",
                    feature_id=feature.id(),
                    detail=errors[0].what() if errors else "",
                    bbox=box,
                )
            if extent is not None and not extent.contains(geometry.boundingBox()):
                collector.add(
                    "G03",
                    feature_id=feature.id(),
                    detail=(
                        f"tọa độ X {box[0]:.3f}, Y {box[1]:.3f} ngoài "
                        f"{_describe_extent(extent)} của {vector_layer.crs().authid()}"
                    ),
                    bbox=box,
                )
            if "L04" in codes:
                length = geometry.length()
                if length <= options.min_line_length:
                    collector.add(
                        "L04",
                        feature_id=feature.id(),
                        detail=f"độ dài {length:.4f} (ngưỡng {options.min_line_length})",
                        bbox=box,
                    )

            if needs_geometry_cache:
                geometries[feature.id()] = QgsGeometry(geometry)
                index.addFeature(feature)
                if needs_attributes:
                    values = feature.attributes()
                    attribute_keys[feature.id()] = tuple(
                        values[index] for index in compared_fields if index < len(values)
                    )
    except Exception as error:
        result.note = f"Không đọc hết đối tượng của lớp: {error}"

    if geometries and index is not None:
        if progress is not None:
            progress.note(f"{layer.name}: so sánh {len(geometries)} đối tượng theo cặp")
        _scan_pairs(geometries, attribute_keys, index, codes, duplicate_code, collector, options)
    if "A03" in codes and len(geometries) > 1:
        if progress is not None:
            progress.note(f"{layer.name}: tìm khe hở giữa {len(geometries)} vùng")
        _scan_gaps(geometries, collector, options)

    result.defects = collector.defects
    result.counts = collector.counts
    return result


def _same_geometry(geometry: QgsGeometry, other: QgsGeometry) -> bool:
    """So sánh hai hình; hình lỗi làm GEOS báo ngoại lệ thì coi như hai hình khác nhau."""
    try:
        return bool(geometry.equals(other))
    except Exception as error:
        QgsMessageLog.logMessage(f"Không so sánh được hai hình: {error}", LOG_TAG, WARNING_LEVEL)
        return False


def _overlap(geometry: QgsGeometry, other: QgsGeometry) -> QgsGeometry | None:
    """Phần chồng đè của hai hình; None nếu không chồng đè hoặc GEOS không giao được."""
    try:
        shared = geometry.intersection(other)
    except Exception as error:
        QgsMessageLog.logMessage(f"Không giao được hai hình: {error}", LOG_TAG, WARNING_LEVEL)
        return None
    if shared is None or shared.isEmpty():
        return None
    return shared


def _scan_pairs(
    geometries: dict[int, QgsGeometry],
    attribute_keys: dict[int, tuple],
    index: QgsSpatialIndex,
    codes: set[str],
    duplicate_code: str,
    collector: _DefectCollector,
    options,
) -> None:
    """So sánh từng cặp đối tượng có khung bao giao nhau: trùng lặp (G01/P01/L02/A02) và chồng đè (A01)."""
    check_duplicate = "G01" in codes or duplicate_code in codes
    check_overlap = "A01" in codes
    if not check_duplicate and not check_overlap:
        return

    compared: set[tuple[int, int]] = set()
    for feature_id, geometry in geometries.items():
        for other_id in index.intersects(geometry.boundingBox()):
            if other_id == feature_id or other_id not in geometries:
                continue
            pair = (min(feature_id, other_id), max(feature_id, other_id))
            if pair in compared:
                continue
            compared.add(pair)
            other = geometries[other_id]

            if _same_geometry(geometry, other):
                if not check_duplicate:
                    continue
                same_attributes = (
                    "G01" in codes
                    and attribute_keys
                    and attribute_keys.get(pair[0]) == attribute_keys.get(pair[1])
                )
                if same_attributes:
                    collector.add(
                        "G01", feature_id=pair[0], other_id=pair[1], bbox=_bbox(geometry)
                    )
                elif duplicate_code in codes:
                    collector.add(
                        duplicate_code, feature_id=pair[0], other_id=pair[1], bbox=_bbox(geometry)
                    )
                continue

            if not check_overlap:
                continue
            shared = _overlap(geometry, other)
            if shared is None:
                continue
            area = shared.area()
            if area > options.min_overlap_area:
                collector.add(
                    "A01",
                    feature_id=pair[0],
                    other_id=pair[1],
                    detail=f"diện tích chồng đè {area:.3f}",
                    bbox=_bbox(shared),
                )


def _scan_gaps(geometries: dict[int, QgsGeometry], collector: _DefectCollector, options) -> None:
    """Khe hở giữa các vùng = lỗ bên trong hình gộp của toàn bộ đối tượng trong lớp."""
    try:
        merged = QgsGeometry.unaryUnion(list(geometries.values()))
    except Exception:
        return
    if merged is None or merged.isEmpty():
        return

    try:
        polygons = merged.asMultiPolygon() if merged.isMultipart() else [merged.asPolygon()]
    except Exception:
        return
    for rings in polygons:
        for ring in rings[1:]:  # ring đầu là biên ngoài, các ring sau là lỗ
            hole = QgsGeometry.fromPolygonXY([ring])
            if hole is None or hole.isEmpty():
                continue
            area = hole.area()
            if area < options.min_gap_area:
                continue
            box = hole.boundingBox()
            collector.add(
                "A03",
                detail=(
                    f"diện tích {area:.3f} tại X {box.center().x():.1f}, Y {box.center().y():.1f}"
                ),
                bbox=(box.xMinimum(), box.yMinimum(), box.xMaximum(), box.yMaximum()),
            )
