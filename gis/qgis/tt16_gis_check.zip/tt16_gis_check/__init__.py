"""Plugin QGIS kiểm tra hồ sơ GIS theo Thông tư 16/2025/TT-BXD - Phụ lục II.

Created by Hoa Le.
Giấy phép: GNU General Public License phiên bản 2 hoặc mới hơn (GPL-2.0-or-later), xem tệp LICENSE.
"""


def classFactory(iface):  # noqa: N802 - tên bắt buộc theo QGIS API
    from .plugin import TT16GisCheckPlugin

    return TT16GisCheckPlugin(iface)
